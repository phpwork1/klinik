<?php

namespace common\components\helpers;

use Yii;
use yii\base\Component;
use yii\base\InvalidConfigException;

class AppConst extends Component {

    const APP_NAME = 'PT. ANEKA';
    const APP_ADDRESS = 'Jl. Kepulan Asap no.113';
    const APP_CITY = 'Jambi';
    const APP_PROVINCE = 'Jambi';
    const APP_ZIP_CODE = '';
    const APP_PHONE = '(0741) 21292';
    const APP_MOBILE = '';
    const APP_INVOICE_PRINTER = '2';
    const APP_RECEIPT_PRINTER = '2';
    const CASHSALE_INVOICE = 'CS';
    const EXPENSE_INVOICE = 'EX';
    const INCOME_INVOICE = 'IN';
    const PRODUCT_HISTORY_INVOICE = 'PH';
    const PURCHASE_ORDER_INVOICE = 'PO';
    const PURCHASE_PAYMENT_INVOICE = 'PP';
    const PURCHASE_RETURN_INVOICE = 'PR';
    const PURCHASE_RECEIPT_INVOICE = 'PT';
    const DELIVERY_ORDER_INVOICE = 'DO';
    const SALE_ORDER_INVOICE = 'SO';
    const SALE_PAYMENT_INVOICE = 'SP';
    const SALE_RETURN_INVOICE = 'SR';
    const SALE_RECEIPT_INVOICE = 'ST';
    
    /**
     *
     * @var array get months from january to december
     * @example TsConst::$month 
     */
    public static $month = [
        '01' => 'Januari',
        '02' => 'Februari',
        '03' => 'Maret',
        '04' => 'April',
        '05' => 'Mei',
        '06' => 'Juni',
        '07' => 'Juli',
        '08' => 'Agustus',
        '09' => 'September',
        '10' => 'Oktober',
        '11' => 'November',
        '12' => 'Desember'
    ];

    /**
     *
     * @var array get months from january to december
     * @example TsConst::$month 
     */
    public static $mnth = [
        '1' => 'Januari',
        '2' => 'Februari',
        '3' => 'Maret',
        '4' => 'April',
        '5' => 'Mei',
        '6' => 'Juni',
        '7' => 'Juli',
        '8' => 'Agustus',
        '9' => 'September',
        '1  0' => 'Oktober',
        '11' => 'November',
        '12' => 'Desember'
    ];
    
    /**
     * code
     */
    public static $code = [
        0 => 's',
        1 => 'c',
        2 => 'h',
        3 => 'a',
        4 => 'n',
        5 => 'd',
        6 => 'r',
        7 => 'i',
        8 => 'k',
        9 => 'u',
    ];

}
