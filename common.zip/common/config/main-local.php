<?php

return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=evnzer',
            'username' => 'root',
            'password' => '21292',
            'charset' => 'utf8',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@common/mail',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => true,
        ],
//        'formatter' => [
//            'class' => 'yii\i18n\Formatter',
//            'dateFormat' => 'php:Y-m-d',
//            'datetimeFormat' => 'php:Y-m-d H:i',
//            'timeFormat' => 'php:H:i',
//            'timeZone' => 'Jakarta',
//        ],
    ],
];
