<?php
return [
    'APP_NAME' => 'Yii site',
];
