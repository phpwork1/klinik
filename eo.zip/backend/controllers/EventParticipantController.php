<?php

namespace backend\controllers;

use backend\models\Event;
use backend\models\EventParticipant;
use backend\models\EventParticipantSearch;
use Yii;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;
use yii\web\Controller;
use yii\web\NotFoundHttpException;

/**
 * EventParticipantController implements the CRUD actions for EventParticipant model.
 */
class EventParticipantController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all EventParticipant models.
     * @return mixed
     */
    public function actionReport()
    {
        $searchModel = new EventParticipantSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        //$total = $searchModel->total(Yii::$app->request->queryParams, ['field' => 'total']);

        return $this->render('report', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            //'total' => $total,
        ]);
    }


    /**
     * Lists all EventParticipant models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new EventParticipantSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single EventParticipant model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', ['model' => $this->findModel($id)]);
    }

    /**
     * Creates a new EventParticipant model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @param $event_id
     * @return mixed
     * @throws NotFoundHttpException
     */
    public function actionCreate($event_id)
    {
        if (Event::findOne($event_id) == null) {
            throw new NotFoundHttpException('The requested page does not exist.');
        }

        $model = new EventParticipant();
        $model->event_id = $event_id;
        $participants = ArrayHelper::map(EventParticipant::find()->all(), 'person_id', 'person_id');;
        $model->participants = array_keys($participants);

        if ($model->load(Yii::$app->request->post()) && $model->transactionSave()) {
            Yii::$app->session->setFlash('success', Yii::t('app', 'Event Participant successfully created.'));
            return $this->redirect(['index', 'EventParticipantSearch[event_id]' => $event_id]);
        } else {
            return $this->render('create', ['model' => $model]);
        }
    }

    /**
     * Updates an existing EventParticipant model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->transactionSave()) {
            Yii::$app->session->setFlash('success', Yii::t('app', 'Event Participant successfully updated.'));
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', ['model' => $model]);
        }
    }

    /**
     * Deletes an existing EventParticipant model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        Yii::$app->session->setFlash('success', Yii::t('app', 'Event Participant successfully deleted.'));
        return $this->redirect(['index']);
    }

    /**
     * Finds the EventParticipant model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return EventParticipant the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = EventParticipant::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
