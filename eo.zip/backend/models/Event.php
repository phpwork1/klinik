<?php

namespace backend\models;

use Yii;
use yii\helpers\ArrayHelper;
use yii\db\Expression;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\helpers\Html;

/**
 * This is the model class for table "event".
 *
 * @property integer $id
 * @property integer $type_id
 * @property string $name
 * @property string $description_short
 * @property string $description_full
 * @property string $venue
 * @property string $address
 * @property string $regency
 * @property string $province
 * @property integer $country
 * @property string $location
 * @property string $latitude
 * @property string $longitude
 * @property string $language
 * @property string $teachers
 * @property string $assistants
 * @property string $fee
 * @property string $contacts
 * @property string $start
 * @property string $end
 * @property string $application_deadline
 * @property string $payment_deadline
 * @property string $created_at
 * @property integer $created_by
 * @property string $updated_at
 * @property integer $updated_by
 * @property string $deleted_at
 * @property integer $deleted_by
 * @property Event[] $map
 *
 * @property EventType $type
 * @property District $district
 * @property User $createdBy
 * @property User $updatedBy
 * @property User $deletedBy
 * @property EventParticipant[] $participants
 */
class Event extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'event';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['type_id', 'created_by', 'updated_by', 'deleted_by'], 'integer'],
            [['name', 'description_short', 'description_full', 'venue', 'address', 'language', 'teachers', 'assistants', 'fee', 'contacts', 'start', 'end', 'application_deadline', 'payment_deadline'], 'required'],
            [['description_full', 'contacts'], 'string'],
            [['latitude', 'longitude'], 'number'],
            [['start', 'end', 'application_deadline', 'payment_deadline', 'created_at', 'updated_at', 'deleted_at'], 'safe'],
            [['name', 'venue', 'address'], 'string', 'max' => 128],
            [['description_short', 'teachers', 'assistants'], 'string', 'max' => 255],
            [['regency', 'province', 'country'], 'string', 'max' => 36],
            [['fee'], 'string', 'max' => 24],
            [['type_id'], 'exist', 'skipOnError' => true, 'targetClass' => EventType::className(), 'targetAttribute' => ['type_id' => 'id']],
            [['deleted_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['deleted_by' => 'id']],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['created_by' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['updated_by' => 'id']],
            [['deleted_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['deleted_by' => 'id']],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['created_by' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['updated_by' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'type_id' => Yii::t('app', 'Type'),
            'name' => Yii::t('app', 'Name'),
            'description_short' => Yii::t('app', 'Description Short'),
            'description_full' => Yii::t('app', 'Description Full'),
            'venue' => Yii::t('app', 'Venue'),
            'address' => Yii::t('app', 'Address'),
            'district' => Yii::t('app', 'District'),
            'regency' => Yii::t('app', 'Regency'),
            'province' => Yii::t('app', 'Province'),
            'country' => Yii::t('app', 'Country'),
            'location' => Yii::t('app', 'Location'),
            'latitude' => Yii::t('app', 'Latitude'),
            'longitude' => Yii::t('app', 'Longitude'),
            'language' => Yii::t('app', 'Language'),
            'teachers' => Yii::t('app', 'Teachers'),
            'assistants' => Yii::t('app', 'Assistants'),
            'fee' => Yii::t('app', 'Fee'),
            'contacts' => Yii::t('app', 'Contacts'),
            'start' => Yii::t('app', 'Start'),
            'end' => Yii::t('app', 'End'),
            'application_deadline' => Yii::t('app', 'Application Deadline'),
            'payment_deadline' => Yii::t('app', 'Payment Deadline'),
            'created_at' => Yii::t('app', 'Created'),
            'created_by' => Yii::t('app', 'By'),
            'updated_at' => Yii::t('app', 'Updated'),
            'updated_by' => Yii::t('app', 'By'),
            'deleted_at' => Yii::t('app', 'Deleted'),
            'deleted_by' => Yii::t('app', 'By'),
        ];
    }

    /**
    * @return \yii\behaviors\TimestampBehavior
    */
    public function behaviors() {
        return [
            'timestamp' => [
                'class' => TimestampBehavior::className(),
                'attributes' => [
                    ActiveRecord::EVENT_BEFORE_INSERT => ['created_at'],
                    ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                    ActiveRecord::EVENT_BEFORE_DELETE => ['deleted_at'],
                ],
                'value' => new Expression('NOW()'),
            ],
        ];
    }
    
    /**
    * @inheritdoc
    */
    public function beforeSave($insert) {
        if ($this->isNewRecord) {
            $this->created_by = Yii::$app->user->id;
        } else {
            $this->updated_by = Yii::$app->user->id;
        }
        return parent::beforeSave($insert);
    }

    public function beforeDelete()
    {
        $this->deleted_by = Yii::$app->user->id;
        return parent::beforeDelete();
    }

    /**
    * Return model objects
    * @param string $value default to 'name'
    * @param string $conditions default to null
    * @return \yii\db\ActiveQuery
    */
    public static function getAll($value = 'name', $conditions = null) {
        $query = Event::find()->orderBy([$value => SORT_ASC]);
        if (!empty($conditions)) {
            $query->andWhere($conditions);
        }
        return $query->all();
    }


    /**
    * Return array of key => value for dropdown menu
    * @param string $key default to 'id'
    * @param string $value default to 'name'
    * @param string $conditions default to null
    * @return Array
    */
    public static function map($key = 'id', $value = 'name', $conditions = null) {
        $key = empty($key) ? 'id' : $key;
        $value = empty($value) ? 'name' : $value;
        $map = ArrayHelper::map(self::getAll($value, $conditions), $key, $value);
        if (empty($map)) {
            Yii::$app->session->setFlash('danger', Yii::t('app', 'Event database still empty. Please add the data as soon as possible.'));
        }
        return $map;
    }


    /**
     * @return \yii\db\ActiveQuery
     */
    public function getType()
    {
        return $this->hasOne(EventType::className(), ['id' => 'type_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'updated_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDeletedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'deleted_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getParticipants()
    {
        return $this->hasMany(EventParticipant::className(), ['event_id' => 'id']);
    }

    public function getLocation() {
        return Html::a('<i class="glyphicon glyphicon-map-marker"></i>', "https://maps.google.com/?q={$this->latitude},{$this->longitude}", ['target' => 'blank']);
    }

    public function getDayCount() {
        $start = new \DateTime($this->start);
        $end = new \DateTime($this->end);

        return $start->diff($end)->format('%a');
    }
}
