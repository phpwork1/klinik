<?php

namespace backend\models;

use common\components\helpers\AppConst;
use Yii;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\db\Expression;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;

/**
 * This is the model class for table "event_participant".
 *
 * @property integer $id
 * @property integer $event_id
 * @property integer $person_id
 * @property string $paid
 * @property string $paid_amount
 * @property string $payment_confirmation
 * @property string $payment_note
 * @property string $created_at
 * @property string $transportation
 * @property string $vehicle_quantity
 * @property string $passenger_seat
 * @property string $passenger
 * @property integer $created_by
 * @property string $updated_at
 * @property integer $updated_by
 * @property string $deleted_at
 * @property integer $deleted_by
 * @property EventParticipant[] $map
 * @property string $participants
 *
 * @property Event $event
 * @property Person $person
 * @property User $createdBy
 * @property User $updatedBy
 * @property User $deletedBy
 */
class EventParticipant extends \yii\db\ActiveRecord
{
    const SCENARIO_PAYMENT = 'payment';
    const SCENARIO_TRANSPORTATION = 'transportation';

    public $directory = 'uploads/payment/';
    public $participants;
    public $payment_upload;

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'event_participant';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['event_id'], 'required'],
            [['paid', 'paid_amount' ,'payment_confirmation', 'payment_note'], 'required', 'on' => self::SCENARIO_PAYMENT],
            [['transportation'], 'required', 'on' => self::SCENARIO_TRANSPORTATION],
            [['vehicle_quantity' ,'passenger_seat'], 'integer', 'on' => self::SCENARIO_TRANSPORTATION],
            [['event_id', 'person_id', 'vehicle_quantity', 'passenger_seat', 'created_by', 'updated_by', 'deleted_by'], 'integer'],
            [['created_at', 'updated_at', 'deleted_at', 'participants', 'paid', 'paid_amount', 'payment_confirmation', 'payment_note', 'suggestion'], 'safe'],
            ['participants', 'string'],
            [['event_id'], 'exist', 'skipOnError' => true, 'targetClass' => Event::className(), 'targetAttribute' => ['event_id' => 'id']],
            [['person_id'], 'exist', 'skipOnError' => true, 'targetClass' => Person::className(), 'targetAttribute' => ['person_id' => 'id']],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['created_by' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['updated_by' => 'id']],
            [['deleted_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['deleted_by' => 'id']],
        ];
    }

    public function scenarios()
    {
        $scenarios = parent::scenarios();
        $scenarios[self::SCENARIO_PAYMENT] = ['paid', 'paid_amount', 'payment_confirmation', 'payment_note'];
        $scenarios[self::SCENARIO_TRANSPORTATION] = ['transportation', 'vehicle_quantity', 'passenger_seat', 'passenger'];
        return $scenarios;
    }


    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'event_id' => Yii::t('app', 'Event'),
            'person_id' => Yii::t('app', 'Person'),
            'paid' => Yii::t('app', 'Has paid?'),
            'paid_amount' => Yii::t('app', 'Has paid'),
            'payment_confirmation' => Yii::t('app', 'Payment Confirmation'),
            'payment_upload' => Yii::t('app', 'Payment Confirmation'),
            'payment_note' => Yii::t('app', 'Note / Suggestion'),
            'transportation' => Yii::t('app', 'Transportation'),
            'vehicle_quantity' => Yii::t('app', 'Vehicle Quantity'),
            'passenger_seat' => Yii::t('app', 'Passenger Seat'),
            'passenger' => Yii::t('app', 'Passenger'),
            'created_at' => Yii::t('app', 'Created'),
            'created_by' => Yii::t('app', 'By'),
            'updated_at' => Yii::t('app', 'Updated'),
            'updated_by' => Yii::t('app', 'By'),
            'deleted_at' => Yii::t('app', 'Deleted'),
            'deleted_by' => Yii::t('app', 'By'),
        ];
    }

    /**
     * @return \yii\behaviors\TimestampBehavior
     */
    public function behaviors()
    {
        return [
            'timestamp' => [
                'class' => TimestampBehavior::className(),
                'attributes' => [
                    ActiveRecord::EVENT_BEFORE_INSERT => ['created_at'],
                    ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                    ActiveRecord::EVENT_BEFORE_DELETE => ['deleted_at'],
                ],
                'value' => new Expression('NOW()'),
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function beforeSave($insert)
    {
        if ($this->isNewRecord) {
            $this->created_by = Yii::$app->user->id;
        } else {
            $this->updated_by = Yii::$app->user->id;
        }
        return parent::beforeSave($insert);
    }

    /**
     * Return model objects
     * @param string $value default to 'name'
     * @param string $conditions default to null
     * @return \yii\db\ActiveQuery
     */
    public static function getAll($value = 'person.name', $conditions = null)
    {
        $query = EventParticipant::find()->joinWith(['person'])->orderBy([$value => SORT_ASC]);
        if (!empty($conditions)) {
            $query->andWhere($conditions);
        }
        return $query->all();
    }

    /**
     * Return array of key => value for dropdown menu
     * @param string $key default to 'id'
     * @param string $value default to 'name'
     * @param string $conditions default to null
     * @return Array
     */
    public static function map($key = 'id', $value = 'person.name', $conditions = null)
    {
        $key = empty($key) ? 'id' : $key;
        $value = empty($value) ? 'person.name' : $value;
        $map = ArrayHelper::map(self::getAll($value, $conditions), $key, $value);
        if (empty($map)) {
            Yii::$app->session->setFlash('danger', Yii::t('app', 'EventParticipant database still empty. Please add the data as soon as possible.'));
        }
        return $map;
    }


    /**
     * @return \yii\db\ActiveQuery
     */
    public function getEvent()
    {
        return $this->hasOne(Event::className(), ['id' => 'event_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPerson()
    {
        return $this->hasOne(Person::className(), ['id' => 'person_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'updated_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDeletedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'deleted_by']);
    }

    public function getEventLink()
    {
        return Html::a($this->event->name, ['/event/view', 'id' => $this->event_id], ['target' => 'blank']);
    }

    public function getPersonName()
    {
        return Html::a($this->person->name, ['/person/view', 'id' => $this->person_id], ['target' => 'blank']);
    }

    /**
     * @return bool save order data. return true if success, false if fail
     * @throws \Exception
     * @internal param Yii $array ::$app->request->post() POST data
     */
    public function transactionSave()
    {
        $transaction = EventParticipant::getDb()->beginTransaction();
        $clean[] = TRUE;

        try {
            ## SAVE DATA
            $oldParticipants = ArrayHelper::map(EventParticipant::find()->all(), 'id', 'id');
            $deleteCandidate = array_diff($oldParticipants, $this->participants);
            $updateCandidate = array_diff($this->participants, $oldParticipants);

            ## DELETE OLD PARTICIPANTS
            foreach ($deleteCandidate as $candidate) {
                $clean[] = EventParticipant::findOne($candidate)->delete() !== false;
            }

            ## UPDATE NEW PARTICIPANTS
            foreach ($updateCandidate as $candidate) {
                $model = new EventParticipant();
                $model->event_id = $this->event_id;
                $model->person_id = $candidate;
                $clean[] = $model->save() !== false;
            }

            if (!in_array(FALSE, $clean)) {
                $transaction->commit();
                return TRUE;
            } else {
                foreach ($this->errors as $attr => $errors) {
                    $error = join('<br />', $errors);
                    Yii::$app->session->addFlash('danger', Yii::t('app', $error));
                }
                return FALSE;
            }
        } catch (Exception $ex) {
            $transaction->rollBack();
            throw($ex);
        }
    }

    public function savePayment()
    {
        $transaction = EventParticipant::getDb()->beginTransaction();
        $clean[] = TRUE;

        try {
            ## SAVE PAYMENT
            if (!in_array(FALSE, $clean)) {
                $transaction->commit();
                return TRUE;
            } else {
                foreach ($this->errors as $attr => $errors) {
                    $error = join('<br />', $errors);
                    Yii::$app->session->addFlash('danger', Yii::t('app', $error));
                }
                return FALSE;
            }
        } catch (Exception $ex) {
            $transaction->rollBack();
            throw($ex);
        }
    }

    public function saveTransportation()
    {
        $transaction = EventParticipant::getDb()->beginTransaction();
        $clean[] = TRUE;

        try {
            ## SAVE TRANSPORTATION
            switch ($this->transportation) {
                case AppConst::SELF_SERVICE:
                case AppConst::NEED_TRANSPORT:
                    $this->vehicle_quantity = null;
                    $this->passenger_seat = null;
                    $this->passenger = null;
                    break;
                case AppConst::HAVE_VEHICLE:
                    if (!empty($this->passenger)) {
                        $this->passenger = join(',', $this->passenger);
                    }
                    break;
            }
            $clean[] = $this->save() !== false;

            if (!in_array(FALSE, $clean)) {
                $transaction->commit();
                return TRUE;
            } else {
                foreach ($this->errors as $attr => $errors) {
                    $error = join('<br />', $errors);
                    Yii::$app->session->addFlash('danger', Yii::t('app', $error));
                }
                return FALSE;
            }
        } catch (Exception $ex) {
            $transaction->rollBack();
            throw($ex);
        }
    }

    /**
     * Delete order step by step, update product stock
     * @return bool delete order data. return true if success, false if fail
     * @throws \Exception
     * @internal param int $id
     */
    public
    function transactionDelete()
    {
        $transaction = Mail::getDb()->beginTransaction();
        $clean[] = TRUE;

        try {
            ## DELETE DETAIL DATA
            foreach ($this->orderDetails as $orderDetail) {
                $clean[] = $orderDetail->transactionDelete() !== FALSE;
            }

            ## DELETE DATA
            $clean[] = $this->delete() !== FALSE;

            if (!in_array(FALSE, $clean)) {
                $transaction->commit();
                return TRUE;
            } else {
                foreach ($this->errors as $attr => $errors) {
                    $error = join('<br />', $errors);
                    Yii::$app->session->addFlash('danger', Yii::t('app', $error));
                }
                return FALSE;
            }
        } catch (Exception $ex) {
            $transaction->rollBack();
            throw($ex);
        }
    }

}
