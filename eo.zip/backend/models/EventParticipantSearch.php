<?php

namespace backend\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use backend\models\EventParticipant;

/**
 * EventParticipantSearch represents the model behind the search form about `backend\models\EventParticipant`.
 */
class EventParticipantSearch extends EventParticipant
{
    public $sum = NULL;

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'event_id', 'person_id', 'passenger_seat', 'created_by', 'updated_by', 'deleted_by'], 'integer'],
            [['created_at', 'updated_at', 'deleted_at', 'paid', 'paid_amount', 'payment_confirmation', 'payment_note', 'transportation', 'vehicle_quantity', 'passenger'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Create data provider summary instance with search query applied
     * @param array $params
     * @param array $sum
     * @return ActiveDataProvider
     */
    public function total($params = null, $sum = null) {
        $this->sum = $sum;
        return $this->search($params);
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = EventParticipant::find();
        $sort = ['defaultOrder' => ['created_at' => SORT_DESC]];
        $pagination = ['pageSize' => 20];

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => $sort,
            'pagination' => $pagination,
        ]);

        $dataProvider->sort->attributes['created_by'] = [
            'asc' => ['user.username' => SORT_ASC],
            'desc' => ['user.username' => SORT_DESC]
        ];
        $dataProvider->sort->attributes['updated_by'] = [
            'asc' => ['user.username' => SORT_ASC],
            'desc' => ['user.username' => SORT_DESC]
        ];

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'event_participant.id' => $this->id,
            'event_participant.event_id' => $this->event_id,
            'event_participant.person_id' => $this->person_id,
            'event_participant.paid' => $this->paid,
            'event_participant.vehicle_quantity' => $this->vehicle_quantity,
            'event_participant.passenger_seat' => $this->passenger_seat,
            'event_participant.created_by' => $this->created_by,
            'event_participant.updated_by' => $this->updated_by,
            'event_participant.deleted_by' => $this->deleted_by,
        ]);

        $query
            ->andFilterWhere(['like', 'event_participant.payment_note', $this->payment_note])
            ->andFilterWhere(['like', 'event_participant.paid_amount', $this->paid_amount])
            ->andFilterWhere(['like', 'event_participant.payment_confirmation', $this->payment_confirmation])
            ->andFilterWhere(['like', 'event_participant.created_at', $this->created_at])
            ->andFilterWhere(['like', 'event_participant.updated_at', $this->updated_at])
            ->andFilterWhere(['like', 'event_participant.deleted_at', $this->deleted_at]);
            
        return (!empty($this->sum)) ? $query->sum($this->sum['field']) : $dataProvider;
    }
}
