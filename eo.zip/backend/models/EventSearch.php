<?php

namespace backend\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use backend\models\Event;

/**
 * EventSearch represents the model behind the search form about `backend\models\Event`.
 */
class EventSearch extends Event
{
    public $sum = NULL;
    public $ltstart;
    public $gtstart;
    public $ltend;
    public $gtend;

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'type_id', 'created_by', 'updated_by', 'deleted_by'], 'integer'],
            [['name', 'description_short', 'description_full', 'venue', 'address', 'country', 'regency', 'province', 'language', 'teachers', 'assistants', 'fee', 'contacts', 'start', 'end', 'application_deadline', 'payment_deadline', 'created_at', 'updated_at', 'deleted_at', 'ltstart', 'gtstart', 'ltend', 'gtend'], 'safe'],
            [['latitude', 'longitude'], 'number'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Create data provider summary instance with search query applied
     * @param array $params
     * @param array $sum
     * @return ActiveDataProvider
     */
    public function total($params = null, $sum = null) {
        $this->sum = $sum;
        return $this->search($params);
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Event::find();
        $sort = ['defaultOrder' => ['name' => SORT_ASC]];
        $pagination = ['pageSize' => 20];

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => $sort,
            'pagination' => $pagination,
        ]);

        $dataProvider->sort->attributes['created_by'] = [
            'asc' => ['user.username' => SORT_ASC],
            'desc' => ['user.username' => SORT_DESC]
        ];
        $dataProvider->sort->attributes['updated_by'] = [
            'asc' => ['user.username' => SORT_ASC],
            'desc' => ['user.username' => SORT_DESC]
        ];

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'event.id' => $this->id,
            'event.type_id' => $this->type_id,
            'event.latitude' => $this->latitude,
            'event.longitude' => $this->longitude,
            'event.start' => $this->start,
            'event.end' => $this->end,
            'event.application_deadline' => $this->application_deadline,
            'event.payment_deadline' => $this->payment_deadline,
            'event.created_by' => $this->created_by,
            'event.updated_by' => $this->updated_by,
            'event.deleted_by' => $this->deleted_by,
        ]);

        $query->andFilterWhere(['like', 'event.name', $this->name])
            ->andFilterWhere(['like', 'event.description_short', $this->description_short])
            ->andFilterWhere(['like', 'event.description_full', $this->description_full])
            ->andFilterWhere(['like', 'event.venue', $this->venue])
            ->andFilterWhere(['like', 'event.address', $this->address])
            ->andFilterWhere(['like', 'event.regency', $this->regency])
            ->andFilterWhere(['like', 'event.province', $this->province])
            ->andFilterWhere(['like', 'event.country', $this->country])
            ->andFilterWhere(['like', 'event.language', $this->language])
            ->andFilterWhere(['like', 'event.teachers', $this->teachers])
            ->andFilterWhere(['like', 'event.assistants', $this->assistants])
            ->andFilterWhere(['like', 'event.fee', $this->fee])
            ->andFilterWhere(['like', 'event.contacts', $this->contacts])
            ->andFilterWhere(['like', 'event.created_at', $this->created_at])
            ->andFilterWhere(['like', 'event.updated_at', $this->updated_at])
            ->andFilterWhere(['like', 'event.deleted_at', $this->deleted_at])
            ->andFilterWhere(['<=', 'event.start', $this->ltstart])
            ->andFilterWhere(['>=', 'event.start', $this->gtstart])
            ->andFilterWhere(['<=', 'event.end', $this->ltend])
            ->andFilterWhere(['>=', 'event.end', $this->gtend]);

        return (!empty($this->sum)) ? $query->sum($this->sum['field']) : $dataProvider;
    }
}
