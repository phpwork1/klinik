<?php

namespace backend\models;

use Yii;
use yii\helpers\ArrayHelper;
use yii\db\Expression;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;

/**
 * This is the model class for table "mail".
 *
 * @property integer $id
 * @property integer $event_id
 * @property string $to
 * @property string $cc
 * @property string $bcc
 * @property string $subject
 * @property string $content
 * @property string $created_at
 * @property integer $created_by
 * @property string $updated_at
 * @property integer $updated_by
 * @property string $deleted_at
 * @property integer $deleted_by
 * @property Mail[] $map
 *
 * @property User $from0
 */
class Mail extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'mail';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['created_by', 'updated_by', 'deleted_by'], 'integer'],
            [['to', 'subject', 'content'], 'required'],
            [['content'], 'string'],
            [['created_at', 'updated_at', 'deleted_at'], 'safe'],
            [['to', 'cc', 'bcc', 'subject'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'from' => Yii::t('app', 'From'),
            'to' => Yii::t('app', 'To'),
            'cc' => Yii::t('app', 'Cc'),
            'bcc' => Yii::t('app', 'Bcc'),
            'subject' => Yii::t('app', 'Subject'),
            'content' => Yii::t('app', 'Content'),
            'created_at' => Yii::t('app', 'Created'),
            'created_by' => Yii::t('app', 'From'),
            'updated_at' => Yii::t('app', 'Updated'),
            'updated_by' => Yii::t('app', 'By'),
            'deleted_at' => Yii::t('app', 'Deleted'),
            'deleted_by' => Yii::t('app', 'By'),
        ];
    }

    /**
    * @return \yii\behaviors\TimestampBehavior
    */
    public function behaviors() {
        return [
            'timestamp' => [
                'class' => TimestampBehavior::className(),
                'attributes' => [
                    ActiveRecord::EVENT_BEFORE_INSERT => ['created_at'],
                    ActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                    ActiveRecord::EVENT_BEFORE_DELETE => ['deleted_at'],
                ],
                'value' => new Expression('NOW()'),
            ],
        ];
    }
    
    /**
    * @inheritdoc
    */
    public function beforeSave($insert) {
        if ($this->isNewRecord) {
            $this->created_by = Yii::$app->user->id;
        } else {
            $this->updated_by = Yii::$app->user->id;
        }
        return parent::beforeSave($insert);
    }
    
    /**
    * Return model objects
    * @param string $value default to 'name'
    * @param string $conditions default to null
    * @return \yii\db\ActiveQuery
    */
    public static function getAll($value = 'name', $conditions = null) {
        $query = Mail::find()->orderBy([$value => SORT_ASC]);
        if (!empty($conditions)) {
            $query->andWhere($conditions);
        }
        return $query->all();
    }

    /**
    * Return array of key => value for dropdown menu
    * @param string $key default to 'id'
    * @param string $value default to 'name'
    * @param string $conditions default to null
    * @return Array
    */
    public static function map($key = 'id', $value = 'name', $conditions = null) {
        $key = empty($key) ? 'id' : $key;
        $value = empty($value) ? 'name' : $value;
        $map = ArrayHelper::map(self::getAll($value, $conditions), $key, $value);
        if (empty($map)) {
            Yii::$app->session->setFlash('danger', Yii::t('app', 'Mail database still empty. Please add the data as soon as possible.'));
        }
        return $map;
    }


    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'updated_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDeletedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'deleted_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getEvent()
    {
        return $this->hasOne(Event::className(), ['id' => 'event_id']);
    }

    public function getRecipient() {
        $result = '...';
        if (!strpos($this->to, ',')) {
            $result = User::findOne($this->to);
        }
        return $result;
    }

    public function getTos() {
        $result = '';
        $tos = explode(',', $this->to);
        $people = Person::findAll(['id' => $tos]);
        foreach ($people as $person) {
            $result .= '<div class="">' . $person->name . '</div>';
        }
        return $result;
    }

    /**
     * @return bool save order data. return true if success, false if fail
     * @throws \Exception
     * @internal param Yii $array ::$app->request->post() POST data
     */
    public function transactionSave() {
        $total = 0;
        $request = Yii::$app->request->post();
        $transaction = Mail::getDb()->beginTransaction();
        $clean[] = TRUE;

        try {
            ## JOIN to, cc, bcc, with ','
            if (strpos($this->to, ',')) {
                $this->to = join(',', $this->to);                
            }
            if (strpos($this->to, ',')) {
                $this->cc = join(',', $this->cc);                
            }
            if (strpos($this->bcc, ',')) {
                $this->bcc = join(',', $this->bcc);                
            }

            ## SAVE DATA
            $clean[] = $this->save() !== FALSE;

            if (!in_array(FALSE, $clean)) {
                $transaction->commit();
                return TRUE;
            } else {
                foreach ($this->errors as $attr => $errors) {
                    $error = join('<br />', $errors);
                    Yii::$app->session->addFlash('danger', Yii::t('app', $error));
                }
                return FALSE;
            }
        } catch (Exception $ex) {
            $transaction->rollBack();
            throw($ex);
        }
    }

    /**
     * Delete order step by step, update product stock
     * @return bool delete order data. return true if success, false if fail
     * @throws \Exception
     * @internal param int $id
     */
    public function transactionDelete() {
        $transaction = Mail::getDb()->beginTransaction();
        $clean[] = TRUE;

        try {
            ## DELETE DETAIL DATA
            foreach ($this->orderDetails as $orderDetail) {
                $clean[] = $orderDetail->transactionDelete() !== FALSE;
            }

            ## DELETE DATA
            $clean[] = $this->delete() !== FALSE;

            if (!in_array(FALSE, $clean)) {
                $transaction->commit();
                return TRUE;
            } else {
                foreach ($this->errors as $attr => $errors) {
                    $error = join('<br />', $errors);
                    Yii::$app->session->addFlash('danger', Yii::t('app', $error));
                }
                return FALSE;
            }
        } catch (Exception $ex) {
            $transaction->rollBack();
            throw($ex);
        }
    }

}
