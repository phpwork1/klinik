<?php

namespace backend\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use backend\models\ParticipantTransportation;

/**
 * ParticipantTransportationSearch represents the model behind the search form about `backend\models\ParticipantTransportation`.
 */
class ParticipantTransportationSearch extends ParticipantTransportation
{
    public $sum = NULL;

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'person_id', 'event_id', 'passanger_seat', 'passanger', 'created_by', 'updated_by', 'deleted_at', 'deleted_by'], 'integer'],
            [['latitude', 'longitude'], 'number'],
            [['gathering_time', 'created_at', 'updated_at'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Create data provider summary instance with search query applied
     * @param array $params
     * @param array $sum
     * @return ActiveDataProvider
     */
    public function total($params = null, $sum = null) {
        $this->sum = $sum;
        return $this->search($params);
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = ParticipantTransportation::find();
        $sort = ['defaultOrder' => ['name' => SORT_ASC]];
        $pagination = ['pageSize' => 20];

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => $sort,
            'pagination' => $pagination,
        ]);

        $dataProvider->sort->attributes['created_by'] = [
            'asc' => ['user.username' => SORT_ASC],
            'desc' => ['user.username' => SORT_DESC]
        ];
        $dataProvider->sort->attributes['updated_by'] = [
            'asc' => ['user.username' => SORT_ASC],
            'desc' => ['user.username' => SORT_DESC]
        ];

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'participant_transportation.id' => $this->id,
            'participant_transportation.person_id' => $this->person_id,
            'participant_transportation.event_id' => $this->event_id,
            'participant_transportation.passanger_seat' => $this->passanger_seat,
            'participant_transportation.passanger' => $this->passanger,
            'participant_transportation.latitude' => $this->latitude,
            'participant_transportation.longitude' => $this->longitude,
            'participant_transportation.gathering_time' => $this->gathering_time,
            'participant_transportation.created_at' => $this->created_at,
            'participant_transportation.created_by' => $this->created_by,
            'participant_transportation.updated_at' => $this->updated_at,
            'participant_transportation.updated_by' => $this->updated_by,
            'participant_transportation.deleted_at' => $this->deleted_at,
            'participant_transportation.deleted_by' => $this->deleted_by,
        ]);

        return (!empty($this->sum)) ? $query->sum($this->sum['field']) : $dataProvider;
    }
}
