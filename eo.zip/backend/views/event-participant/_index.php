<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel backend\models\EventParticipantSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$options = ['class' => 'text-center'];
$gridColumns = [
['class' => 'yii\grid\SerialColumn'],
    [
        'attribute' => 'event_id',
        'value' => 'eventLink',
        'format' => 'raw',
        'filter' => \backend\models\Event::map(),
    ],
    [
        'attribute' => 'person_id',
        'value' => 'personName',
        'format' => 'raw',
        'filter' => \backend\models\Person::map(),
    ],
    [
        'attribute' => 'paid',
        'value' => 'paid',
        'filter' => \common\components\helpers\AppConst::$yesNo,
        'headerOptions' => $options,
        'contentOptions' => $options,
        'footerOptions' => $options,
    ],
    [
        'attribute' => 'paid_amount',
        'format' => ['decimal', 0],
    ],
    [
        'attribute' => 'payment_confirmation',
        'headerOptions' => $options,
        'contentOptions' => $options,
        'footerOptions' => $options,
    ],
    'created_at',
    [
        'attribute' => 'created_by',
        'value' => 'createdBy.username',
        'filter' => \backend\models\User::map(),
    ],
    'updated_at',
    [
        'attribute' => 'updated_by',
        'value' => 'updatedBy.username',
        'filter' => \backend\models\User::map(),
    ],
    ['class' => 'yii\grid\ActionColumn',
        'header' => 'Actions',
        'template' => '{mail} {update} {delete}',
        'buttons' => [
            'mail' => function ($url, $model) {
                return Html::a('<i class="glyphicon glyphicon-envelope"></i>', ['/mail/create', 'event_id' => $model->event_id, 'person_id' => $model->id], ['class' => 'btn-sm btn-primary']);
            },
            'update' => function ($url, $model) {
                return Html::a('<i class="glyphicon glyphicon-pencil"></i>', ['/event-participant/update', 'id' => $model->id], ['class' => 'btn-sm btn-warning']);
            },
            'delete' => function ($url, $model) {
                return Html::a('<i class="glyphicon glyphicon-remove"></i>', ['/event-participant/delete', 'id' => $model->id], ['class' => 'btn-sm btn-danger']);
            }
        ],
        'contentOptions' => ['class' => 'text-nowrap'],
        ],
    ];

echo GridView::widget([
    'dataProvider' => $dataProvider,
    'filterModel' => $searchModel,
    'columns' => $gridColumns,
]);
