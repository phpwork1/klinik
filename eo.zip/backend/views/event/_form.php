<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\widgets\DateTimePicker;

/* @var $this yii\web\View */
/* @var $model backend\models\Event */
/* @var $form yii\widgets\ActiveForm */

\backend\assets\Wysihtml5Asset::register($this);
$this->registerJs("
    $('#event-contacts').wysihtml5();
");
?>

<div class="box-body event-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'type_id')->dropDownList(\backend\models\EventType::map()) ?>

    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'description_short')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'description_full')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'venue')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'address')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'regency')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'province')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'country')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'latitude')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'longitude')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'language')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'teachers')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'assistants')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'fee')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'contacts')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'start')->widget(DateTimePicker::classname(), [
        'options' => ['placeholder' => 'Event start time ..'],
        'pluginOptions' => [
            'autoclose' => true,
            'todayBtn' => true,
            'minViewMode' => 1,
            'maxViewMode' => 2,
            'todayHighlight' => true,
        ]])
        ?>

    <?= $form->field($model, 'end')->widget(DateTimePicker::classname(), [
            'options' => ['placeholder' => 'Event end time ..'],
            'pluginOptions' => [
                'autoclose' => true
            ]])
        ?>

    <?= $form->field($model, 'application_deadline')->widget(DateTimePicker::classname(), [
            'options' => ['placeholder' => 'Event end time ..'],
            'pluginOptions' => [
                'autoclose' => true
            ]])
        ?>

    <?= $form->field($model, 'payment_deadline')->widget(DateTimePicker::classname(), [
            'options' => ['placeholder' => 'Event end time ..'],
            'pluginOptions' => [
                'autoclose' => true
            ]])
        ?>

    <div class="box-footer">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>

