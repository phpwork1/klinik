<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel backend\models\EventSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Events');
$this->params['breadcrumbs'][] = $this->title;
$this->params['buttons'] = [
    Html::a('<i class="glyphicon glyphicon-plus"></i>', ['create'], [
        'type'=>'button',
        'title'=>Yii::t('app', 'Add Events'),
        'class'=>'btn btn-success'
    ]) . ' '.
    Html::a('<i class="glyphicon glyphicon-repeat"></i>', ['index'], [
        'data-pjax'=>0,
        'class' => 'btn btn-default',
        'title'=>Yii::t('app', 'Reset Grid')
    ])
];

$cssAlign = ['class' => 'text-center'];
$gridColumns = [
['class' => 'yii\grid\SerialColumn'],
    [
        'attribute' => 'type_id',
        'value' => 'type.name',
        'filter' => \backend\models\EventType::map(),
    ],
    'name',
     'venue',
    [
        'attribute' => 'location',
        'label' => 'Loc',
        'format' => 'raw',
        'headerOptions' => $cssAlign,
        'contentOptions' => $cssAlign,
        'footerOptions' => $cssAlign,
    ],
     'teachers',
     'assistants',
     'fee',
    [
        'attribute' => 'start',
        'format' => ['date', 'yyyy-MM-dd'],
    ],
    [
        'attribute' => 'end',
        'format' => ['date', 'yyyy-MM-dd'],
    ],
    [
        'attribute' => 'created_by',
        'value' => 'createdBy.username',
        'filter' => \common\models\User::map(),
    ],
    // 'application_deadline',
    // 'payment_deadline',
    ['class' => 'yii\grid\ActionColumn',
        'header' => 'Actions',
        'template' => '{view} {update} {delete}',
        'contentOptions' => ['class' => 'text-nowrap'],
        ],
    ];

Pjax::begin();echo GridView::widget([
    'dataProvider' => $dataProvider,
    'filterModel' => $searchModel,
    'columns' => $gridColumns,
]);
Pjax::end();