<?php

use yii\helpers\Html;
use yii\grid\GridView;
use kartik\export\ExportMenu;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\EventSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Events');
$this->params['breadcrumbs'][] = $this->title;
$this->params['buttons'] = [
    Html::a('<i class="glyphicon glyphicon-repeat"></i>', ['grid-demo'], [
        'data-pjax'=>0,
        'class' => 'btn btn-default',
        'title'=>Yii::t('app', 'Reset Grid')
    ])
];

$gridColumns = [
    ['class' => 'yii\grid\SerialColumn'],
    [
        'attribute' => 'type_id',
        'value' => 'type.name',
        'filter' => \backend\models\EventType::map(),
    ],
    'name',
    'venue',
    [
        'attribute' => 'location',
        'label' => 'Loc',
        'format' => 'raw',
        'headerOptions' => $cssAlign,
        'contentOptions' => $cssAlign,
        'footerOptions' => $cssAlign,
    ],
    'teachers',
    'assistants',
    'fee',
    [
        'attribute' => 'start',
        'format' => ['date', 'yyyy-mm-dd'],
    ],
    [
        'attribute' => 'end',
        'format' => ['date', 'yyyy-mm-dd'],
    ],
    'created_at',
    [
        'attribute' => 'created_by',
        'value' => 'createdBy.username',
        'filter' => \common\models\User::map(),
    ],
    ['class' => 'yii\grid\ActionColumn',
        'header' => 'Actions',
        'template' => '{view}',
        'contentOptions' => ['class' => 'text-nowrap'],
    ],
];

$this->params['export'] = ExportMenu::widget([
    'dataProvider' => $dataProvider,
    'columns' => $gridColumns,
    //'target' => ExportMenu::TARGET_BLANK,
    'filename' => 'Report ' . $this->title,
    'fontAwesome' => true,
    'dropdownOptions' => [
        'label' => 'Export All',
        'class' => 'btn btn-default'
    ],
]);

echo GridView::widget([
    'dataProvider' => $dataProvider,
    'filterModel' => $searchModel,
    'columns' => $gridColumns,
    'showFooter' => TRUE,
]);
