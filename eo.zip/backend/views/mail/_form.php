<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model backend\models\Mail */
/* @var $form yii\widgets\ActiveForm */

\backend\assets\Wysihtml5Asset::register($this);
$this->registerJs("
    $('#mail-content').wysihtml5();
");
?>

<div class="box-body table-responsive mail-form">

    <?php $form = ActiveForm::begin(); ?>

    <?php if (empty($model->to)): ?>
        <?= $form->field($model, 'to')->checkboxList(\backend\models\EventParticipant::map(null, null, ['event_id' => $model->event_id])) ?>

        <?= $form->field($model, 'cc')->textInput(['maxlength' => true]) ?>

        <?= $form->field($model, 'bcc')->textInput(['maxlength' => true]) ?>
    <?php endif; ?>

    <?= $form->field($model, 'subject')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'content')->textarea(['rows' => 6]) ?>

    <div class="box-footer">
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
