<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model backend\models\Mail */

$this->title = $model->event->name . ' :: ' . $model->subject;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Mails'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
$this->params['buttons'][] = Html::a('<i class="glyphicon glyphicon-pencil"></i>', ['update', 'id' => $model->id], ['class' => 'btn btn-warning']);
$this->params['buttons'][] = Html::a('<i class="glyphicon glyphicon-remove"></i> ', ['delete', 'id' => $model->id], [
'class' => 'btn btn-danger',
'data' => [
'confirm' => Yii::t('app', 'Are you sure you want to delete this item?'),
'method' => 'post',
],
]);
?>
<div class="box box-info">
    <div class="box-header with-border">
        <h3 class="box-title"><?= Html::encode($this->title) ?></h3>
        <br>
        <strong><?= $model->getAttributeLabel('created_at') ?></strong>&nbsp;&nbsp;&nbsp;<?= $model->created_at ?>
        &nbsp;&nbsp;&nbsp;<strong>by</strong>&nbsp;&nbsp;&nbsp;<?= $model->createdBy->person->name ?>
    </div>

    <div class="box-body event-type-form table-responsive">
        <table class="table table-hover table-striped detail-view">
            <tr>
                <th><?= $model->getAttributeLabel('to') ?></th>
                <td><?= $model->tos ?></td>
            </tr>
            <?php if (!empty($this->cc)): ?>
            <tr>
                <th><?= $model->getAttributeLabel('cc') ?></th>
                <td><?= $model->cc ?></td>
            </tr>
            <?php endif ?>
            <?php if (!empty($this->bcc)): ?>
            <tr>
                <th><?= $model->getAttributeLabel('bcc') ?></th>
                <td><?= $model->bcc ?></td>
            </tr>
            <?php endif ?>
            <tr>
                <th><?= $model->getAttributeLabel('subject') ?></th>
                <td><?= $model->subject ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('content') ?></th>
                <td><?= $model->content ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('created_at') ?></th>
                <td><?= $model->created_at ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('created_by') ?></th>
                <td><?= $model->created_by ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('updated_at') ?></th>
                <td><?= $model->updated_at ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('updated_by') ?></th>
                <td><?= $model->updated_by ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('deleted_at') ?></th>
                <td><?= $model->deleted_at ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('deleted_by') ?></th>
                <td><?= $model->deleted_by ?></td>
            </tr>
            </table>
    </div>
</div>
