<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model backend\models\ParticipantTransportation */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Participant Transportations'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
$this->params['buttons'][] = Html::a('<i class="glyphicon glyphicon-pencil"></i>', ['update', 'id' => $model->id], ['class' => 'btn btn-warning']);
$this->params['buttons'][] = Html::a('<i class="glyphicon glyphicon-remove"></i> ', ['delete', 'id' => $model->id], [
'class' => 'btn btn-danger',
'data' => [
'confirm' => Yii::t('app', 'Are you sure you want to delete this item?'),
'method' => 'post',
],
]);
?>
<div class="box box-info">
    <div class="box-header with-border">
        <h3 class="box-title"><?= Html::encode($this->title) ?></h3>
    </div>

    <div class="box-body event-type-form table-responsive">
        <table class="table table-hover table-striped detail-view">
            <tr>
                <th><?= $model->getAttributeLabel('id') ?></th>
                <td><?= $model->id ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('person_id') ?></th>
                <td><?= $model->person_id ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('event_id') ?></th>
                <td><?= $model->event_id ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('passanger_seat') ?></th>
                <td><?= $model->passanger_seat ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('passanger') ?></th>
                <td><?= $model->passanger ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('latitude') ?></th>
                <td><?= $model->latitude ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('longitude') ?></th>
                <td><?= $model->longitude ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('gathering_time') ?></th>
                <td><?= $model->gathering_time ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('created_at') ?></th>
                <td><?= $model->created_at ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('created_by') ?></th>
                <td><?= $model->created_by ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('updated_at') ?></th>
                <td><?= $model->updated_at ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('updated_by') ?></th>
                <td><?= $model->updated_by ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('deleted_at') ?></th>
                <td><?= $model->deleted_at ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('deleted_by') ?></th>
                <td><?= $model->deleted_by ?></td>
            </tr>
            </table>
    </div>
</div>
