<?php
use yii\helpers\Html;

/* @var $this yii\web\View */

$this->title = 'Beranda';
?>
<div class="site-index row">
    <div class="col-md-4">
        <legend>Penjualan</legend>
        <ul>
            <li>Penjualan yang belum lunas sampai saat ini
        </ul>
    </div>
</div>
