<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\UserSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Users');
$this->params['breadcrumbs'][] = $this->title;
$this->params['buttons'] = [
    Html::a('<i class="glyphicon glyphicon-plus"></i> Tambah', ['create'], [
        'type'=>'button',
        'title'=>Yii::t('app', 'Tambah Users'),
        'class'=>'btn btn-success'
    ]) . ' '.
    Html::a('<i class="glyphicon glyphicon-repeat"></i> Refresh', ['index'], [
        'data-pjax'=>0,
        'class' => 'btn btn-default',
        'title'=>Yii::t('app', 'Reset Grid')
    ])
];

$gridColumns = [
    ['class' => 'yii\grid\SerialColumn'],
    [
        'attribute' => 'person_id',
        'format' => 'raw',
        'value' => 'personLink',
        'filter' => backend\models\Person::map(),
    ],
    'email:email',
    [
        'attribute' => 'role',
        'value' => 'roleName',
        'filter' => $searchModel->roles,
    ],
    [
        'attribute' => 'status',
        'value' => 'statusName',
        'filter' => $searchModel->statuses,
    ],
    [
        'attribute' => 'created_at',
        'format' => ['date', 'php:Y-m-d'],
    ],
    [
        'attribute' => 'updated_at',
        'format' => ['date', 'php:Y-m-d'],
    ],
    ['class' => 'yii\grid\ActionColumn',
        'header' => 'Actions',
        'template' => '{update} {delete}',
        'contentOptions' => ['class' => 'text-nowrap'],
    ],
];

echo GridView::widget([
    'dataProvider' => $dataProvider,
    'filterModel' => $searchModel,
    'columns' => $gridColumns,
]);
