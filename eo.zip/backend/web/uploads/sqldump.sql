-- MySQL dump 10.16  Distrib 10.1.10-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: freshyfruit
-- ------------------------------------------------------
-- Server version	10.1.8-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` tinyint(2) unsigned NOT NULL,
  `code` varchar(12) DEFAULT NULL,
  `name` varchar(32) NOT NULL,
  `beginning_balance` bigint(20) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `fk-acc-ac-01` FOREIGN KEY (`category_id`) REFERENCES `account_category` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (1,1,'KAS','KAS',5000000,'2013-11-27','2013-11-27'),(2,1,NULL,'PIUTANG USAHA',0,'2013-11-25','2013-11-25'),(3,1,NULL,'BANK BCA',0,'2013-11-27','2013-11-27'),(4,1,NULL,'BANK MANDIRI',0,'2013-11-27','2013-11-27'),(5,12,NULL,'BEBAN LISTRIK',0,'2013-12-03','2013-11-28'),(6,12,NULL,'BEBAN AIR',0,'2013-12-01','2013-12-05'),(7,10,NULL,'PENJUALAN',0,'2015-08-28',NULL),(8,12,NULL,'PEMBELIAN',0,'2015-08-28',NULL),(9,11,'PDLU','PENDAPATAN LAIN-LAIN',0,'2015-08-28',NULL),(10,6,'123','HUTANG PEMBELIAN',0,'2015-09-05',NULL),(11,13,'500','PENGELUARAN',100000,'2015-09-06',NULL),(12,11,'PDT','Undian BCA',0,'2015-09-06',NULL),(13,11,'TIPS','TIPS',0,'2015-09-06',NULL),(14,13,'TLP','Beban Telepon',0,NULL,NULL);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_category`
--

DROP TABLE IF EXISTS `account_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_category` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` tinyint(2) unsigned NOT NULL,
  `code` varchar(4) NOT NULL,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  CONSTRAINT `fc-ac-ag` FOREIGN KEY (`group_id`) REFERENCES `account_group` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_category`
--

LOCK TABLES `account_category` WRITE;
/*!40000 ALTER TABLE `account_category` DISABLE KEYS */;
INSERT INTO `account_category` VALUES (1,1,'HALC','HARTA LANCAR'),(2,1,'HAI','HARTA INVESTASI'),(3,1,'HATB','HARTA TAK BERWUJUD'),(4,1,'HAT','HARTA TETAP'),(5,1,'HAL','HARTA LAINNYA'),(6,2,'HUC','HUTANG LANCAR'),(7,2,'HUJP','HUTANG JANGKA PANJANG'),(8,2,'HULL','HUTANG LAIN-LAIN'),(9,3,'MDL','MODAL'),(10,4,'PU','PENDAPATAN USAHA'),(11,4,'PLU','PENDAPATAN DI LUAR USAHA'),(12,5,'BU','BEBAN USAHA'),(13,5,'BLU','BEBAN DI LUAR USAHA');
/*!40000 ALTER TABLE `account_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_group`
--

DROP TABLE IF EXISTS `account_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_group` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(4) NOT NULL,
  `name` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_group`
--

LOCK TABLES `account_group` WRITE;
/*!40000 ALTER TABLE `account_group` DISABLE KEYS */;
INSERT INTO `account_group` VALUES (1,'ASET','ASET/HARTA'),(2,'KWJB','KEWAJIBAN'),(3,'EQTS','EQUITAS'),(4,'PDPT','PENDAPATAN'),(5,'PGLR','PENGELUARAN'),(6,'BDA','BIAYA DEPRESIASI DAN AMORTASI'),(7,'LAIN','LAIN');
/*!40000 ALTER TABLE `account_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_assignment` (
  `item_name` varchar(64) NOT NULL,
  `user_id` varchar(64) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_assignment`
--

LOCK TABLES `auth_assignment` WRITE;
/*!40000 ALTER TABLE `auth_assignment` DISABLE KEYS */;
INSERT INTO `auth_assignment` VALUES ('Accounting','12',1420160339),('Accounting','19',1430718623),('Administrator','6',1419223312),('Administrator','7',1419223993),('Kepala Cabang','16',1430718513),('Kepala Cabang','17',1430718548),('Owner','8',1419224032),('Sales Admin','10',1420117993),('Sales Admin','11',1420118327),('Sales Admin','13',1420419972),('Sales Admin','15',1420419972),('Sales Admin','18',1430718577),('Sales Admin','20',1430718669),('Sales Admin','21',1430718697),('Sales Admin','22',1433222686),('Sales Admin','23',1434860437),('Sales Admin','24',1439350656);
/*!40000 ALTER TABLE `auth_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_item` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `rule_name` varchar(64) DEFAULT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx_auth_item_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_item`
--

LOCK TABLES `auth_item` WRITE;
/*!40000 ALTER TABLE `auth_item` DISABLE KEYS */;
INSERT INTO `auth_item` VALUES ('Accounting',1,NULL,NULL,NULL,1419222292,1419222292),('Administrator',1,NULL,NULL,NULL,1419222292,1419222292),('Finance',1,NULL,NULL,NULL,1419222292,1419222292),('Kepala Cabang',1,NULL,NULL,NULL,1419222292,1419222292),('Owner',1,NULL,NULL,NULL,1419222292,1419222292),('Sales Admin',1,NULL,NULL,NULL,1419222292,1419222292),('updatePaidTicket',2,'Update Paid Ticket',NULL,NULL,1424848942,1424848942),('updateUser',2,'Update user',NULL,NULL,1419222291,1419222291);
/*!40000 ALTER TABLE `auth_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_item_child`
--

DROP TABLE IF EXISTS `auth_item_child`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_item_child` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_item_child`
--

LOCK TABLES `auth_item_child` WRITE;
/*!40000 ALTER TABLE `auth_item_child` DISABLE KEYS */;
INSERT INTO `auth_item_child` VALUES ('Accounting','updatePaidTicket'),('Accounting','updateUser'),('Administrator','updatePaidTicket'),('Administrator','updateUser'),('Finance','updatePaidTicket'),('Finance','updateUser'),('Owner','updatePaidTicket'),('Owner','updateUser'),('Sales Admin','updateUser');
/*!40000 ALTER TABLE `auth_item_child` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_rule`
--

DROP TABLE IF EXISTS `auth_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_rule` (
  `name` varchar(64) NOT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_rule`
--

LOCK TABLES `auth_rule` WRITE;
/*!40000 ALTER TABLE `auth_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill_footer`
--

DROP TABLE IF EXISTS `bill_footer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bill_footer` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `footer` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_footer`
--

LOCK TABLES `bill_footer` WRITE;
/*!40000 ALTER TABLE `bill_footer` DISABLE KEYS */;
INSERT INTO `bill_footer` VALUES (1,'Barang yang sudah dibeli \r\ntidak dapat dikembalikan');
/*!40000 ALTER TABLE `bill_footer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_sale`
--

DROP TABLE IF EXISTS `cash_sale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(13) DEFAULT NULL,
  `total` int(10) unsigned NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` smallint(5) unsigned DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `FK_cash_sale_user` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  CONSTRAINT `FK_cash_sale_user_2` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_sale`
--

LOCK TABLES `cash_sale` WRITE;
/*!40000 ALTER TABLE `cash_sale` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_sale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `province_id` tinyint(3) unsigned NOT NULL,
  `code` varchar(4) NOT NULL,
  `name` varchar(24) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `province_id` (`province_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` VALUES (1,7,'DJBK','Jambi Kota'),(2,17,'BKLS','Bengkalis'),(3,17,'TBT','Tanjung Batu'),(4,17,'BTH','Batam');
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `email` varchar(48) DEFAULT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `address` varchar(128) DEFAULT NULL,
  `city_id` smallint(5) unsigned DEFAULT NULL,
  `province_id` tinyint(3) unsigned DEFAULT NULL,
  `zip_code` int(6) unsigned DEFAULT NULL,
  `term_of_payment_id` tinyint(3) unsigned DEFAULT NULL,
  `price_category_id` tinyint(3) unsigned DEFAULT NULL,
  `limit` int(10) unsigned DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `note` text,
  PRIMARY KEY (`id`),
  KEY `city_id` (`city_id`),
  KEY `province_id` (`province_id`),
  KEY `price_category_id` (`price_category_id`),
  KEY `term_of_payment_id` (`term_of_payment_id`),
  CONSTRAINT `fk-cust-city` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-cust-pricecat` FOREIGN KEY (`price_category_id`) REFERENCES `price_category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-cust-prov` FOREIGN KEY (`province_id`) REFERENCES `province` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-cust-top` FOREIGN KEY (`term_of_payment_id`) REFERENCES `term_of_payment` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'CASH','','','',4,17,NULL,1,NULL,NULL,NULL,'Pembeli tunai');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `joined_date` date NOT NULL,
  `name` varchar(32) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  `phone` varchar(32) NOT NULL,
  `salary` int(11) DEFAULT NULL,
  `commission` decimal(5,2) DEFAULT NULL,
  `note` text,
  `status` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'2016-03-01','Tonny Sofijan','Cempaka Putih','0821',10000000,20.00,'','Y'),(2,'2016-04-09','Owner','','0811',5000000,20.00,NULL,'Y'),(3,'2016-04-09','Accounting','','0816',3000000,0.00,NULL,'Y'),(4,'2016-04-09','Operator','','0819',1500000,0.00,NULL,'Y');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expense`
--

DROP TABLE IF EXISTS `expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expense` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(13) DEFAULT NULL,
  `debet` smallint(5) unsigned DEFAULT NULL,
  `credit` smallint(5) unsigned DEFAULT NULL,
  `amount` int(10) unsigned NOT NULL,
  `detail` varchar(128) DEFAULT NULL,
  `date` date NOT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` smallint(5) unsigned DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `debet` (`debet`),
  KEY `credit` (`credit`),
  CONSTRAINT `fk-exps-acc-01` FOREIGN KEY (`debet`) REFERENCES `account` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-exps-acc-02` FOREIGN KEY (`credit`) REFERENCES `account` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-exps-user-01` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-exps-user-02` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expense`
--

LOCK TABLES `expense` WRITE;
/*!40000 ALTER TABLE `expense` DISABLE KEYS */;
/*!40000 ALTER TABLE `expense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `income`
--

DROP TABLE IF EXISTS `income`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `income` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(13) DEFAULT NULL,
  `debet` smallint(5) unsigned DEFAULT NULL,
  `credit` smallint(5) unsigned DEFAULT NULL,
  `amount` int(10) unsigned NOT NULL,
  `detail` varchar(128) DEFAULT NULL,
  `date` date NOT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` smallint(5) unsigned DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `debet` (`debet`),
  KEY `credit` (`credit`),
  CONSTRAINT `fk-inc-acc-01` FOREIGN KEY (`debet`) REFERENCES `account` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-inc-acc-02` FOREIGN KEY (`credit`) REFERENCES `account` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-inc-user-01` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-inc-user-02` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `income`
--

LOCK TABLES `income` WRITE;
/*!40000 ALTER TABLE `income` DISABLE KEYS */;
/*!40000 ALTER TABLE `income` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parameter`
--

DROP TABLE IF EXISTS `parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parameter` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(48) NOT NULL,
  `address` varchar(96) NOT NULL,
  `city` varchar(24) NOT NULL,
  `province` varchar(24) NOT NULL,
  `zip_code` int(5) NOT NULL,
  `phone` varchar(32) NOT NULL,
  `mobile` varchar(32) DEFAULT NULL,
  `pin` varchar(10) DEFAULT NULL,
  `facebook` varchar(64) DEFAULT NULL,
  `twitter` varchar(64) DEFAULT NULL,
  `logo` varchar(50) DEFAULT NULL,
  `slogan` varchar(128) DEFAULT NULL,
  `app_name` varchar(48) NOT NULL,
  `header` varchar(128) DEFAULT NULL,
  `footer` varchar(128) DEFAULT NULL,
  `invoice_printer` char(1) NOT NULL DEFAULT '0' COMMENT '0=struk;1=invoice;2=kwitansi',
  `receipt_printer` char(1) NOT NULL DEFAULT '1' COMMENT '0=struk;1=invoice;2=kwitansi',
  `reset_username` varchar(24) DEFAULT NULL,
  `reset_password` varchar(50) DEFAULT NULL,
  `empty_username` varchar(24) DEFAULT NULL,
  `empty_password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parameter`
--

LOCK TABLES `parameter` WRITE;
/*!40000 ALTER TABLE `parameter` DISABLE KEYS */;
INSERT INTO `parameter` VALUES (1,'FreshyFruit','PACCEKA PLAZA ','Bengkalis','Riau',28751,'-','','','','','','','FreshyFruit','','','1','2','','','','');
/*!40000 ALTER TABLE `parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_category`
--

DROP TABLE IF EXISTS `price_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `price_category` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(4) NOT NULL,
  `name` varchar(24) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_category`
--

LOCK TABLES `price_category` WRITE;
/*!40000 ALTER TABLE `price_category` DISABLE KEYS */;
INSERT INTO `price_category` VALUES (1,'ECR','ECERAN');
/*!40000 ALTER TABLE `price_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_list`
--

DROP TABLE IF EXISTS `price_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `price_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned DEFAULT NULL,
  `price_category_id` tinyint(3) unsigned DEFAULT NULL,
  `price` double(14,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `price_category_id` (`price_category_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `fk-pl-pc-01` FOREIGN KEY (`price_category_id`) REFERENCES `price_category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-pl-product-01` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_list`
--

LOCK TABLES `price_list` WRITE;
/*!40000 ALTER TABLE `price_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `price_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `printer`
--

DROP TABLE IF EXISTS `printer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `printer` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `computer_name` varchar(32) NOT NULL,
  `computer_user` varchar(24) DEFAULT NULL,
  `computer_password` varchar(24) DEFAULT NULL,
  `printer_name` varchar(32) NOT NULL,
  `printer_type` char(1) NOT NULL,
  `printer_port` varchar(5) DEFAULT NULL,
  `print_quality` char(1) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `printer`
--

LOCK TABLES `printer` WRITE;
/*!40000 ALTER TABLE `printer` DISABLE KEYS */;
INSERT INTO `printer` VALUES (1,'DESKTOP-NNGCFQT','SMC-PC','larismanis','TM-U220B','1','LPT1','1',''),(2,'DESKTOP-NNGCFQT','SMC-PC','larismanis','LX310','2','LPT2','1',''),(3,'rio-pc','rio','123456789','lq310','1','lpt1','1','');
/*!40000 ALTER TABLE `printer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(16) DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  `category_id` smallint(5) unsigned DEFAULT NULL,
  `brand_id` smallint(5) unsigned DEFAULT NULL,
  `pricelist` int(10) unsigned NOT NULL DEFAULT '0',
  `discount1` decimal(4,2) unsigned NOT NULL DEFAULT '0.00',
  `discount2` decimal(4,2) NOT NULL DEFAULT '0.00',
  `capital` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `quantity` decimal(10,2) NOT NULL DEFAULT '0.00',
  `minimum_quantity` tinyint(3) unsigned DEFAULT '0',
  `unit_id` tinyint(3) unsigned DEFAULT NULL,
  `location` varchar(12) DEFAULT NULL,
  `note` text,
  `created_at` date DEFAULT NULL,
  `created_by` smallint(5) unsigned DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`),
  KEY `category_id` (`category_id`),
  KEY `unit_id` (`unit_id`),
  KEY `created_by` (`created_by`,`updated_by`),
  KEY `updated_by` (`updated_by`),
  KEY `updated_by_2` (`updated_by`),
  KEY `unit_id_2` (`unit_id`),
  CONSTRAINT `fk-product-ib-01` FOREIGN KEY (`brand_id`) REFERENCES `product_brand` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-product-ic-01` FOREIGN KEY (`category_id`) REFERENCES `product_category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-product-unit-01` FOREIGN KEY (`unit_id`) REFERENCES `product_unit` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-product-user-01` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-product-user-02` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (2,'101','Apel',1,1,50000,10.00,0.00,45000,60000,4.60,0,1,'','\r\n \r\n','2016-04-11',1,'2016-04-11',4),(3,'102','Apel',1,3,40000,10.00,0.00,36000,50000,13.90,0,1,'','','2016-04-11',1,'2016-04-11',2),(4,'201','Jeruk',1,2,20000,10.00,0.00,18000,25000,48.10,0,1,'','','2016-04-11',1,'2016-04-11',2);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_brand`
--

DROP TABLE IF EXISTS `product_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_brand` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(24) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_brand`
--

LOCK TABLES `product_brand` WRITE;
/*!40000 ALTER TABLE `product_brand` DISABLE KEYS */;
INSERT INTO `product_brand` VALUES (2,'Brastagi'),(1,'Royal Gala'),(3,'Washington');
/*!40000 ALTER TABLE `product_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_category`
--

DROP TABLE IF EXISTS `product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_category` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(24) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_category`
--

LOCK TABLES `product_category` WRITE;
/*!40000 ALTER TABLE `product_category` DISABLE KEYS */;
INSERT INTO `product_category` VALUES (1,'Buah');
/*!40000 ALTER TABLE `product_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_history`
--

DROP TABLE IF EXISTS `product_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(13) DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `date` date NOT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` smallint(5) unsigned DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `fk-sh-product-01` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-sh-user-01` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-sh-user-02` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_history`
--

LOCK TABLES `product_history` WRITE;
/*!40000 ALTER TABLE `product_history` DISABLE KEYS */;
INSERT INTO `product_history` VALUES (3,'PH160411-0001',4,-5.00,'Rusak','2016-04-11','2016-04-11',1,NULL,NULL),(4,'PH160411-0001',2,-2.00,'rusak','2016-04-11','2016-04-11',1,NULL,NULL),(5,'PH160411-0001',3,1.00,'','2016-04-11','2016-04-11',2,NULL,NULL);
/*!40000 ALTER TABLE `product_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_unit`
--

DROP TABLE IF EXISTS `product_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_unit` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(24) NOT NULL,
  `code` char(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_unit`
--

LOCK TABLES `product_unit` WRITE;
/*!40000 ALTER TABLE `product_unit` DISABLE KEYS */;
INSERT INTO `product_unit` VALUES (1,'kilogram','kg'),(2,'piece','pc'),(3,'kotak','ktk');
/*!40000 ALTER TABLE `product_unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `province`
--

DROP TABLE IF EXISTS `province`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `province` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(28) NOT NULL,
  `capital` varchar(24) NOT NULL,
  `iso_code` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `iso_code` (`iso_code`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `province`
--

LOCK TABLES `province` WRITE;
/*!40000 ALTER TABLE `province` DISABLE KEYS */;
INSERT INTO `province` VALUES (1,'Aceh','Banda Aceh','ID_AC'),(2,'Bali','Denpasar','ID_BA'),(3,'Banten','Serang','ID_BT'),(4,'Bengkulu','Bengkulu','ID_BE'),(5,'Gorontalo','Gorontalo','ID_GO'),(6,'Jakarta','Jakarta','ID_JK'),(7,'Jambi','Jambi','ID_JA'),(8,'Jawa Barat','Bandung','ID_JB'),(9,'Jawa Tengah','Semarang','ID_JT'),(10,'Jawa Timur','Surabaya','ID_JI'),(11,'Kalimantan Barat','Pontianak','ID_KB'),(12,'Kalimantan Selatan','Banjarmasin','ID_KS'),(13,'Kalimantan Tengah','Palangkaraya','ID_KT'),(14,'Kalimantan Timur','Samarinda','ID_KI'),(15,'Kalimantan Utara','Tanjung Selor','ID_KU'),(16,'Kepulauan Bangka Belitung','Pangkal Pinang','ID_BB'),(17,'Kepulauan Riau','Pangkal Pinang','ID_KR'),(18,'Lampung','Bandar Lampung','ID_LA'),(19,'Maluku','Ambon','ID_MA'),(20,'Maluku Utara','Sofifi','ID_MU'),(21,'Nusa Tenggara Barat','Mataram','ID_NB'),(22,'Nusa Tenggara Timur','Kupang','ID_NT'),(23,'Papua','Jayapura','ID_PA'),(24,'Papua Barat','Manokrawi','ID_PB'),(25,'Riau','Pekanbaru','ID_RI'),(26,'Sulawesi Barat','Mamuju','ID_SR'),(27,'Sulawesi Selatan','Makassar','ID_SN'),(28,'Sulawesi Tengah','Palu','ID_ST'),(29,'Sulawesi Tenggara','Kendari','ID_SG'),(30,'Sulawesi Utara','Manado','ID_SA'),(31,'Sumatera Barat','Padang','ID_SB'),(32,'Sumatera Selatan','Palembang','ID_SS'),(33,'Sumatera Utara','Medan','ID_SU'),(34,'Yogyakarta','Yogyakarta','ID_YO');
/*!40000 ALTER TABLE `province` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order`
--

DROP TABLE IF EXISTS `purchase_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(13) NOT NULL,
  `supplier_id` smallint(5) unsigned DEFAULT NULL,
  `receipt_id` int(10) unsigned DEFAULT NULL,
  `term_of_payment_id` tinyint(3) NOT NULL DEFAULT '0',
  `tax_id` tinyint(3) unsigned DEFAULT NULL,
  `tax_no` varchar(24) DEFAULT NULL,
  `other_costs` int(10) unsigned NOT NULL DEFAULT '0',
  `include_ppn` char(1) NOT NULL DEFAULT 'N',
  `ppn` decimal(4,2) NOT NULL DEFAULT '0.00',
  `discount` double(5,2) NOT NULL,
  `total` double(11,2) NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'O' COMMENT 'O=open;L=locked;S=settled',
  `printed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` smallint(5) unsigned DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `payment_id` (`receipt_id`),
  KEY `tax_id` (`tax_id`),
  KEY `term_of_payment_id` (`term_of_payment_id`),
  CONSTRAINT `fk-purch-receipt-01` FOREIGN KEY (`receipt_id`) REFERENCES `purchase_receipt` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-purch-suppl-01` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-purch-user-01` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-purch-user-02` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-purhc-tax-01` FOREIGN KEY (`tax_id`) REFERENCES `tax` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order`
--

LOCK TABLES `purchase_order` WRITE;
/*!40000 ALTER TABLE `purchase_order` DISABLE KEYS */;
INSERT INTO `purchase_order` VALUES (1,'PO160411-0001',1,NULL,30,NULL,NULL,0,'N',0.00,0.00,1350000.00,'O',0,'2016-04-11','2016-04-11',1,'2016-04-11',1),(2,'PO160411-0002',1,NULL,30,NULL,NULL,0,'N',0.00,0.00,720000.00,'O',0,'2016-04-11','2016-04-11',1,'2016-04-11',1);
/*!40000 ALTER TABLE `purchase_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order_detail`
--

DROP TABLE IF EXISTS `purchase_order_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `pricelist` int(10) unsigned NOT NULL DEFAULT '0',
  `disc1` decimal(4,2) NOT NULL DEFAULT '0.00',
  `disc2` decimal(4,2) NOT NULL DEFAULT '0.00',
  `price` int(10) unsigned NOT NULL,
  `quantity` decimal(10,2) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `purchase_id` (`order_id`),
  CONSTRAINT `fk-pod-po-01` FOREIGN KEY (`order_id`) REFERENCES `purchase_order` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk-pod-product-01` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_detail`
--

LOCK TABLES `purchase_order_detail` WRITE;
/*!40000 ALTER TABLE `purchase_order_detail` DISABLE KEYS */;
INSERT INTO `purchase_order_detail` VALUES (1,1,2,50000,10.00,0.00,45000,10.00),(2,1,4,20000,10.00,0.00,18000,50.00),(3,2,3,40000,10.00,0.00,36000,15.00),(4,2,4,20000,10.00,0.00,18000,10.00);
/*!40000 ALTER TABLE `purchase_order_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_payment`
--

DROP TABLE IF EXISTS `purchase_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_payment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned DEFAULT NULL,
  `invoice_no` varchar(13) DEFAULT NULL,
  `debet` smallint(5) unsigned DEFAULT NULL,
  `credit` smallint(5) unsigned DEFAULT NULL,
  `amount` int(10) unsigned NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `date` date NOT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` smallint(5) unsigned DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `debet` (`debet`),
  KEY `credit` (`credit`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `fk-pp-acc-cr` FOREIGN KEY (`credit`) REFERENCES `account` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-pp-acc-dr` FOREIGN KEY (`debet`) REFERENCES `account` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-pp-po-01` FOREIGN KEY (`order_id`) REFERENCES `purchase_order` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-pp-user-01` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-pp-user-02` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_payment`
--

LOCK TABLES `purchase_payment` WRITE;
/*!40000 ALTER TABLE `purchase_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_receipt`
--

DROP TABLE IF EXISTS `purchase_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_receipt` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(13) DEFAULT NULL,
  `supplier_id` smallint(5) unsigned DEFAULT NULL,
  `total` int(10) NOT NULL,
  `printed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` smallint(5) unsigned DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `fk_pr_supplier_01` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_pr_user_01` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_pr_user_02` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_receipt`
--

LOCK TABLES `purchase_receipt` WRITE;
/*!40000 ALTER TABLE `purchase_receipt` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_return`
--

DROP TABLE IF EXISTS `purchase_return`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_return` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(13) NOT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `print` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0: waiting for approval, 1: approved',
  `date` date NOT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` smallint(5) unsigned DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `fk-pr-po-01` FOREIGN KEY (`order_id`) REFERENCES `purchase_order` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-pr-user-01` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-pr-user-02` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_return`
--

LOCK TABLES `purchase_return` WRITE;
/*!40000 ALTER TABLE `purchase_return` DISABLE KEYS */;
INSERT INTO `purchase_return` VALUES (2,'PR160411-0001',1,0,'2016-04-11','2016-04-11',1,NULL,NULL);
/*!40000 ALTER TABLE `purchase_return` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_return_detail`
--

DROP TABLE IF EXISTS `purchase_return_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_return_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `return_id` int(10) unsigned DEFAULT NULL,
  `order_detail_id` int(10) unsigned DEFAULT NULL,
  `quantity` decimal(10,2) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `return_id` (`return_id`),
  KEY `order_detail_id` (`order_detail_id`),
  CONSTRAINT `fk-prd-pod-01` FOREIGN KEY (`order_detail_id`) REFERENCES `purchase_order_detail` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-prd-pr-01` FOREIGN KEY (`return_id`) REFERENCES `purchase_return` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_return_detail`
--

LOCK TABLES `purchase_return_detail` WRITE;
/*!40000 ALTER TABLE `purchase_return_detail` DISABLE KEYS */;
INSERT INTO `purchase_return_detail` VALUES (2,2,1,10.00);
/*!40000 ALTER TABLE `purchase_return_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(8) NOT NULL,
  `name` varchar(48) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'ADM','ADMINISTRATOR'),(2,'OWN','Owner'),(3,'ACC','Accounting'),(4,'FINANCE','Finance'),(5,'SLA','Sales Admin'),(6,'OB','Office Boy'),(7,'BM','Branch Manager');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_order`
--

DROP TABLE IF EXISTS `sale_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(13) NOT NULL,
  `customer_id` smallint(5) unsigned DEFAULT NULL,
  `receipt_id` int(10) unsigned DEFAULT NULL,
  `term_of_payment_id` tinyint(3) NOT NULL DEFAULT '0',
  `tax_id` tinyint(3) unsigned DEFAULT NULL,
  `tax_no` varchar(24) DEFAULT NULL,
  `other_costs` int(10) unsigned NOT NULL DEFAULT '0',
  `include_ppn` char(1) NOT NULL DEFAULT 'N',
  `ppn` decimal(4,2) NOT NULL DEFAULT '0.00',
  `discount` double(5,2) NOT NULL,
  `total` double(11,2) NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'O' COMMENT 'O=Open;L=locked;S=settled',
  `printed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` smallint(5) unsigned DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `payment_id` (`receipt_id`),
  KEY `tax_id` (`tax_id`),
  KEY `term_of_payment_id` (`term_of_payment_id`),
  CONSTRAINT `fk-so-cust-01` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-so-receipt-01` FOREIGN KEY (`receipt_id`) REFERENCES `sale_receipt` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-so-tax-01` FOREIGN KEY (`tax_id`) REFERENCES `tax` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-so-user-01` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-so-user-02` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_order`
--

LOCK TABLES `sale_order` WRITE;
/*!40000 ALTER TABLE `sale_order` DISABLE KEYS */;
INSERT INTO `sale_order` VALUES (5,'SO160411-0001',1,NULL,0,NULL,NULL,0,'N',0.00,0.00,25000.00,'S',5,'2016-04-11','2016-04-11',1,'2016-04-11',1),(6,'SO160411-0002',1,NULL,0,NULL,NULL,0,'N',0.00,0.00,60000.00,'S',2,'2016-04-11','2016-04-11',1,'2016-04-11',1),(7,'SO160411-0003',1,NULL,0,NULL,NULL,0,'N',0.00,0.00,177000.00,'S',1,'2016-04-11','2016-04-11',1,'2016-04-11',1),(8,'SO160411-0004',1,NULL,0,NULL,NULL,0,'N',0.00,0.00,25000.00,'S',2,'2016-04-11','2016-04-11',2,'2016-04-11',2),(10,'SO160411-0005',1,NULL,0,NULL,NULL,0,'N',0.00,0.00,60000.00,'S',1,'2016-04-11','2016-04-11',2,'2016-04-11',2),(11,'SO160411-0006',1,NULL,0,NULL,NULL,0,'N',0.00,0.00,72000.00,'S',3,'2016-04-11','2016-04-11',4,'2016-04-11',4),(12,'SO160411-0007',1,NULL,0,NULL,NULL,0,'N',0.00,0.00,25000.00,'S',1,'2016-04-11','2016-04-11',2,'2016-04-11',2);
/*!40000 ALTER TABLE `sale_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_order_detail`
--

DROP TABLE IF EXISTS `sale_order_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_order_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `capital` int(10) unsigned NOT NULL,
  `price` int(10) unsigned NOT NULL,
  `quantity` decimal(10,2) unsigned NOT NULL,
  `disc` double(4,2) unsigned NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `sale_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `fk-sod-product-01` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-sod-so-01` FOREIGN KEY (`order_id`) REFERENCES `sale_order` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_order_detail`
--

LOCK TABLES `sale_order_detail` WRITE;
/*!40000 ALTER TABLE `sale_order_detail` DISABLE KEYS */;
INSERT INTO `sale_order_detail` VALUES (2,5,4,18000,25000,1.50,0.00),(4,6,4,18000,25000,2.40,0.00),(5,7,2,45000,60000,1.20,0.00),(6,7,3,36000,50000,2.10,0.00),(7,8,4,18000,25000,1.00,0.00),(8,10,2,45000,60000,1.00,0.00),(9,11,2,45000,60000,1.20,0.00),(10,12,4,18000,25000,1.00,0.00);
/*!40000 ALTER TABLE `sale_order_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_payment`
--

DROP TABLE IF EXISTS `sale_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_payment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned DEFAULT NULL,
  `invoice_no` varchar(13) DEFAULT NULL,
  `debet` smallint(5) unsigned DEFAULT NULL,
  `credit` smallint(5) unsigned DEFAULT NULL,
  `amount` int(10) NOT NULL,
  `note` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` smallint(5) unsigned DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `debet` (`debet`),
  KEY `credit` (`credit`),
  CONSTRAINT `fk-sp-acc-cr` FOREIGN KEY (`credit`) REFERENCES `account` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-sp-acc-dr` FOREIGN KEY (`debet`) REFERENCES `account` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-sp-user-01` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-sp-user-02` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_payment`
--

LOCK TABLES `sale_payment` WRITE;
/*!40000 ALTER TABLE `sale_payment` DISABLE KEYS */;
INSERT INTO `sale_payment` VALUES (2,5,'SP160411-0001',1,NULL,25000,'CASH','2016-04-11','2016-04-11',1,NULL,NULL),(4,6,'SP160411-0002',1,NULL,60000,'CASH','2016-04-11','2016-04-11',1,NULL,NULL),(5,7,'SP160411-0003',1,NULL,177000,'CASH','2016-04-11','2016-04-11',1,NULL,NULL),(6,8,'SP160411-0004',1,NULL,25000,'CASH','2016-04-11','2016-04-11',2,NULL,NULL),(7,10,'SP160411-0005',1,NULL,60000,'CASH','2016-04-11','2016-04-11',2,NULL,NULL),(8,11,'SP160411-0006',1,NULL,72000,'CASH','2016-04-11','2016-04-11',4,NULL,NULL),(9,12,'SP160411-0007',1,NULL,25000,'CASH','2016-04-11','2016-04-11',2,NULL,NULL);
/*!40000 ALTER TABLE `sale_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_receipt`
--

DROP TABLE IF EXISTS `sale_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_receipt` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(13) DEFAULT NULL,
  `customer_id` smallint(5) unsigned DEFAULT NULL,
  `total` int(10) NOT NULL,
  `printed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` smallint(5) unsigned DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `fk_sr_customer_01` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_sr_user_01` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_sr_user_02` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_receipt`
--

LOCK TABLES `sale_receipt` WRITE;
/*!40000 ALTER TABLE `sale_receipt` DISABLE KEYS */;
/*!40000 ALTER TABLE `sale_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_return`
--

DROP TABLE IF EXISTS `sale_return`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_return` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(13) NOT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `print` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0: waiting for approval, 1: approved',
  `date` date NOT NULL,
  `created_at` date DEFAULT NULL,
  `created_by` smallint(5) unsigned DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_no` (`invoice_no`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `fk-sr-so-01` FOREIGN KEY (`order_id`) REFERENCES `sale_order` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-sr-user-01` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-sr-user-02` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_return`
--

LOCK TABLES `sale_return` WRITE;
/*!40000 ALTER TABLE `sale_return` DISABLE KEYS */;
/*!40000 ALTER TABLE `sale_return` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_return_detail`
--

DROP TABLE IF EXISTS `sale_return_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_return_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `return_id` int(10) unsigned DEFAULT NULL,
  `order_detail_id` int(10) unsigned DEFAULT NULL,
  `quantity` decimal(10,2) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `return_id` (`return_id`),
  KEY `sale_detail_id` (`order_detail_id`),
  CONSTRAINT `fk-srd-sod-01` FOREIGN KEY (`order_detail_id`) REFERENCES `sale_order_detail` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk-srd-sr-01` FOREIGN KEY (`return_id`) REFERENCES `sale_return` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_return_detail`
--

LOCK TABLES `sale_return_detail` WRITE;
/*!40000 ALTER TABLE `sale_return_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `sale_return_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `email` varchar(48) DEFAULT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `address` varchar(128) DEFAULT NULL,
  `city_id` smallint(5) unsigned DEFAULT NULL,
  `province_id` tinyint(3) unsigned DEFAULT NULL,
  `zip_code` int(6) unsigned DEFAULT NULL,
  `term_of_payment_id` tinyint(3) unsigned DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `note` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (1,'Bengkalis Buah','','','jl. jend. sudirman ',2,25,28712,5,NULL,'');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax`
--

DROP TABLE IF EXISTS `tax`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tax` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(8) NOT NULL,
  `name` varchar(32) NOT NULL,
  `amount` decimal(5,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax`
--

LOCK TABLES `tax` WRITE;
/*!40000 ALTER TABLE `tax` DISABLE KEYS */;
/*!40000 ALTER TABLE `tax` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `term_of_payment`
--

DROP TABLE IF EXISTS `term_of_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `term_of_payment` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(6) NOT NULL,
  `name` varchar(24) NOT NULL,
  `amount` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `term_of_payment`
--

LOCK TABLES `term_of_payment` WRITE;
/*!40000 ALTER TABLE `term_of_payment` DISABLE KEYS */;
INSERT INTO `term_of_payment` VALUES (1,'CASH','Tunai',0),(2,'TOP3','Kredit 3',3),(3,'TOP7','Kredit 7',7),(4,'TOP15','Kredit 15',15),(5,'TOP30','Kredit 30',30);
/*!40000 ALTER TABLE `term_of_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` smallint(5) unsigned NOT NULL,
  `branch_id` tinyint(3) unsigned NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role` smallint(6) NOT NULL DEFAULT '10',
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,2,1,'chen','y2WRdS1s265NVuDR2jFPgc5JJlXD9mgL','$2y$13$tTcbnnbzHptJb1N4xepUTekuQm0FJk4jNVcqJC5fmWkneAoUK3wbK',NULL,'owner@gmail.com',20,10,1419223312,1460343720),(2,4,1,'operator2','ySLXJshhuGJPQUfxVH4u7aWIsXmmKoi-','$2y$13$2ErXq/Bjbt6dTFXaGTXQmuzHVK2H0qZzfAICq6vatcpJYA784h4se',NULL,'op2@gmail.com',60,10,1419223993,1460302455),(3,3,1,'accounting','HVkPNYncvJjhifEp5j4rzJIFl0ZazA6W','$2y$13$n7ENNKgyAXyzw1j9rE5FIuxl8qRHTC//q0QwwDBqtxSNxQrNAh./C',NULL,'acct@gmail.com',30,10,1420117993,1460302432),(4,4,1,'operator1','MQ0p5minZVzcQnb7N_5DEonNXdVj4ZJR','$2y$13$4KLInBnw8GQecGoSg/gvPOvfqxpmXcj929C6tfltIfGyNuYvN8Ylu',NULL,'op1@gmail.com',60,10,1420118327,1460302443),(5,1,1,'tonny','Cx3nqa-pf0iG9TziZn76NWv059W34aZf','$2y$13$iDWStqsVuyy2bMViBgtjm.wwpfnqVz1lUYcNwzCIvSjh2KXmdkV5G',NULL,'a@a.com',10,10,1457708718,1460302653);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-11 22:00:51
