<?php

namespace frontend\controllers;

use backend\models\Event;
use backend\models\EventParticipant;
use backend\models\EventParticipantSearch;
use common\components\helpers\AppConst;
use Yii;
use yii\filters\VerbFilter;
use yii\web\Controller;
use yii\web\NotFoundHttpException;

/**
 * EventParticipantController implements the CRUD actions for EventParticipant model.
 */
class EventParticipantController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all EventParticipant models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new EventParticipantSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        //$total = $searchModel->total(Yii::$app->request->queryParams, ['field' => 'total']);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single EventParticipant model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', ['model' => $this->findModel($id)]);
    }

    /**
     * Creates a new EventParticipant model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @param $event_id
     * @return mixed
     * @throws NotFoundHttpException
     */
    public function actionRegister($event_id)
    {
        if (Event::findOne($event_id) === null) {
            throw new NotFoundHttpException('The requested page does not exist.');
        }

        if ($this->findModel($event_id)) {
            Yii::$app->session->setFlash('warning', Yii::t('app', 'You have been registered to this event.'));
            return $this->redirect(['/event/index']);
        }

        $model = new EventParticipantSearch();
        $model->event_id = $event_id;
        $model->person_id = Yii::$app->user->identity->person_id;

        if ($model->save()) {
            Yii::$app->session->setFlash('success', Yii::t('app', 'You have registered to this event. Do not forget to make a payment before payment deadline.'));
            return $this->redirect(['/event/index', 'EventSearch[id]' => $model->event_id]);
        } else {
            return $this->render('create', ['model' => $model]);
        }
    }

    public function actionTransportation($id, $mode) {
        $model = $this->findModel($id);
        $model->setScenario(EventParticipant::SCENARIO_TRANSPORTATION);
        $model->transportation = $mode;

        if ($model->load(Yii::$app->request->post()) && $model->transactionSave()) {
            Yii::$app->session->setFlash('success', Yii::t('app', 'Event Participant successfully updated.'));
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            if ($model->transportation == AppConst::SELF_SERVICE && $model->saveTransportation()) {
                Yii::$app->session->setFlash('success', Yii::t('app', 'OK, we have noted your transportation preference.'));
                return $this->redirect(['/event/index']);
            } else if ($model->transportation == AppConst::NEED_TRANSPORT && $model->saveTransportation()) {
                Yii::$app->session->setFlash('success', Yii::t('app', 'OK, we have noted your transportation preference.'));
                return $this->redirect(['/event/index']);
            } else if ($model->transportation == AppConst::HAVE_VEHICLE) {
                return $this->render('update', ['model' => $model]);
            } else {
                return $this->redirect(['/event/index']);
                Yii::$app->session->setFlash('danger', Yii::t('app', 'There\'s problem with saving your preference. Contact administrator.'));
            }
        }

    }

    /**
     * Deletes an existing EventParticipant model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $event_id
     * @return mixed
     */
    public function actionDelete($event_id)
    {
        $model = $this->findModel($event_id);
        $model->delete();

        Yii::$app->session->setFlash('success', Yii::t('app', 'You have been un-registered from this event.'));
        return $this->redirect(['/event/index', 'EventSearch[id]' => $model->event_id]);
    }

    /**
     * Finds the EventParticipant model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $event_id
     * @return EventParticipant the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($event_id)
    {
        if (($model = EventParticipant::findOne(['event_id' => $event_id, 'person_id' => Yii::$app->user->identity->person_id])) !== null) {
            return $model;
        } else {
            return false;
            //Yii::$app->session->setFlash('danger', Yii::t('app', 'The requested Event Participant does not exist.'));
            //return $this->redirect(['/event/index', 'EventSearch[id]' => $event_id]);
            //throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
