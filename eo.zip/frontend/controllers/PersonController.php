<?php

namespace frontend\controllers;

use common\models\User;
use Yii;
use backend\models\Person;
use backend\models\PersonSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * PersonController implements the CRUD actions for Person model.
 */
class PersonController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Person models.
     * @return mixed
     */
    public function actionIndex()
    {
        $model = $this->findModel(Yii::$app->user->identity->person_id);
        return $this->render('index', ['model' => $model]);
    }

    /**
     * Creates a new Person model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionRegister()
    {
        Yii::$app->session->setFlash('warning', Yii::t('app', 'Fail to send email. Contact tonny.chua@gmail.com or +62 819 258 8008 to activate account.'));
        return $this->goHome();
        $email = \Yii::$app->mailer->compose()
            ->setTo('tonny.chua@gmail.com')
            ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name . ' robot'])
            ->setSubject('Signup Confirmation')
            ->setTextBody("Click this link " . \yii\helpers\Html::a('confirm',
                    Yii::$app->urlManager->createAbsoluteUrl(
                        ['site/confirm', 'id' => $user->id, 'key' => $user->auth_key]
                    ))
            )
            ->send();
        if ($email) {
            Yii::$app->session->setFlash('success', Yii::t('app', 'Check your email for Activation code.'));
        } else {
            Yii::$app->session->setFlash('warning', Yii::t('app', 'Fail to send email. Contact tonny.chua@gmail.com or +62 819 258 8008 to activate account.'));
        }

        $model = new Person();
        $model->role = User::ROLE_PARTICIPANT;
        $model->setScenario(Person::SCENARIO_REGISTER);

        if ($model->load(Yii::$app->request->post()) && $model->transactionSave()) {
            $user = User::findOne(['person_id' => $model->id]);
            $email = \Yii::$app->mailer->compose()
                ->setTo($model->email)
                ->setFrom([\Yii::$app->params['supportEmail'] => \Yii::$app->name . ' robot'])
                ->setSubject('Signup Confirmation')
                ->setTextBody("Click this link " . \yii\helpers\Html::a('confirm',
                        Yii::$app->urlManager->createAbsoluteUrl(
                            ['site/confirm', 'id' => $user->id, 'key' => $user->auth_key]
                        ))
                )
                ->send();
            if ($email) {
                Yii::$app->session->setFlash('success', Yii::t('app', 'Check your email for Activation code.'));
            } else {
                Yii::$app->session->setFlash('warning', Yii::t('app', 'Fail to send email. Contact your Admin'));
            }
            return $this->redirect(['site/login']);
        } else {
            return $this->render('register', ['model' => $model]);
        }
    }

    /**
     * Updates an existing City model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public
    function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->transactionSave()) {
            Yii::$app->session->setFlash('success', 'Data kota berhasil diubah.');
            return $this->redirect(['index', 'PersonSearch[name]' => $model->name]);
        } else {
            return $this->render('update', ['model' => $model,]);
        }
    }

    /**
     * Updates an existing City model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public
    function actionChangePassword($id)
    {
        $model = $this->findModel($id);
        $model->setScenario(Person::SCENARIO_CHANGE_PASSWORD);

        if ($model->load(Yii::$app->request->post()) && $model->transactionChangePassword()) {
            Yii::$app->session->setFlash('success', 'Password berhasil diubah.');
            return $this->redirect(['index', 'PersonSearch[name]' => $model->name]);
        } else {
            return $this->render('change-password', ['model' => $model,]);
        }
    }

    /**
     * Finds the Person model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Person the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected
    function findModel($id)
    {
        if (($model = Person::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
