<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel backend\models\EventParticipantSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Event Participants');
$this->params['breadcrumbs'][] = $this->title;
$this->params['buttons'] = [
    Html::a('<i class="glyphicon glyphicon-repeat"></i>', ['index'], [
        'data-pjax'=>0,
        'class' => 'btn btn-default',
        'title'=>Yii::t('app', 'Reset Grid')
    ])
];

$gridColumns = [
['class' => 'yii\grid\SerialColumn'],
    [
        'attribute' => 'event_id',
        'value' => 'event.name',
        'filter' => \backend\models\Event::map(),
    ],
    [
        'attribute' => 'person_id',
        'value' => 'person.name',
        'filter' => \backend\models\Person::map(),
    ],
    'created_at',
    [
        'attribute' => 'created_by',
        'value' => 'createdBy.username',
        'filter' => \backend\models\User::map(),
    ],
    'updated_at',
    [
        'attribute' => 'updated_by',
        'value' => 'updatedBy.username',
        'filter' => \backend\models\User::map(),
    ],
    ['class' => 'yii\grid\ActionColumn',
        'header' => 'Actions',
        'template' => '{delete}',
        'buttons' => [
            'delete' => function ($url, $model) {
                return Html::a('<i class="glyphicon glyphicon-remove"></i>', ['/event-participant/delete', 'id' => $model->id], ['class' => 'btn-sm btn-danger']);
            }
        ],
        'contentOptions' => ['class' => 'text-nowrap'],
        ],
    ];

Pjax::begin();echo GridView::widget([
    'dataProvider' => $dataProvider,
    'filterModel' => $searchModel,
    'columns' => $gridColumns,
]);
Pjax::end();