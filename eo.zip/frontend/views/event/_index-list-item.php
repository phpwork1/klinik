<?php
use yii\helpers\Html;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model backend\models\Event */
/* @var $model backend\models\Person */
/* @var $model backend\models\EventParticipant */

?>

<article class="item" data-key="<?= $model->id; ?>">
    <div class="box box-info">
        <div class="box-header with-border">
            <h3 class="box-title"><?= Html::encode($model->name) ?></h3><br>
            <?= empty($model->description_short) ? '- no description -' : $model->description_short ?>

            <div class="box-tools vcenter">
                <?php
                $me = \backend\models\EventParticipant::findOne(['person_id' => Yii::$app->user->identity->person_id, 'event_id' => $model->id]);
                if ($model->end > date('Y-m-d H:i:s')) {
                    if ($me) {
                        if ($me->paid == 'Y') {
                            echo Html::a('<i class="glyphicon glyphicon-thumbs-up"></i>', ['/event-participant/register', 'event_id' => $model->id], ['class' => 'btn btn-success', 'title' => 'confirm payment', 'data' => ['method' => 'post', 'confirm' => Yii::t('app', 'Confirm your payment?')]]);
                        } else {
                            echo Html::a('<i class="glyphicon glyphicon-usd"></i>', ['/event-participant/register', 'event_id' => $model->id], ['class' => 'btn btn-success', 'title' => 'make a payment', 'data' => ['method' => 'post', 'confirm' => Yii::t('app', 'Are you sure you want to make a payment?')]]);
                        }
                        echo '&nbsp;';
                        echo Html::a('<i class="glyphicon glyphicon-remove"></i>', ['/event-participant/delete', 'event_id' => $model->id], ['class' => 'btn btn-danger', 'title' => 'un-register', 'data' => ['method' => 'post', 'confirm' => Yii::t('app', 'Are you sure you want to un-register?')]]);
                    } else {
                        echo Html::a('<i class="glyphicon glyphicon-ok"></i>', ['/event-participant/register', 'event_id' => $model->id], ['class' => 'btn btn-success', 'title' => 'register', 'data' => ['method' => 'post', 'confirm' => Yii::t('app', 'Are you sure you want to un-register?')]]);
                    }
                }
                ?>
            </div>
        </div>
        <div class="box-body event-type-form table-responsive">
            <table class="table table-hover table-striped detail-view table-vcenter">
                <tr>
                    <th><?= $model->getAttributeLabel('type_id') ?></th>
                    <td><?= $model->type->name ?></td>
                </tr>
                <tr>
                    <th><?= $model->getAttributeLabel('venue') ?></th>
                    <td><?= $model->venue ?> <?= $model->location ?></td>
                </tr>
                <tr>
                    <th><?= $model->getAttributeLabel('address') ?></th>
                    <td><?= $model->address ?>, <?= $model->regency ?>, <?= $model->province ?>
                        , <?= $model->country ?></td>
                </tr>
                <tr>
                    <th><?= $model->getAttributeLabel('language') ?></th>
                    <td><?= $model->language ?></td>
                </tr>
                <tr>
                    <th><?= $model->getAttributeLabel('teachers') ?></th>
                    <td><?= $model->teachers ?>&nbsp;&nbsp;-&nbsp;<?= Yii::t('app', 'assisted by') ?>
                        &nbsp;-&nbsp;&nbsp;<?= $model->assistants ?></td>
                </tr>
                <tr>
                    <th><?= $model->getAttributeLabel('start') ?></th>
                    <td><?= Yii::$app->formatter->asDate($model->start, 'Y-MM-dd') ?>
                        <strong><em><?= Yii::t('app', 'to') ?></em></strong> <?= Yii::$app->formatter->asDate($model->end, 'Y-MM-dd') ?>
                        (<?= $model->dayCount ?> <?= Yii::t('app', 'days') ?>)
                    </td>
                </tr>
                <tr>
                    <th><?= $model->getAttributeLabel('fee') ?></th>
                    <td><?= $model->fee ?></td>
                </tr>
                <tr>
                    <th><?= $model->getAttributeLabel('application_deadline') ?></th>
                    <td><?= Yii::$app->formatter->asDate($model->application_deadline, 'Y-MM-dd') ?></td>
                </tr>
                <tr>
                    <th><?= $model->getAttributeLabel('payment_deadline') ?></th>
                    <td><?= Yii::$app->formatter->asDate($model->payment_deadline, 'Y-MM-dd') ?></td>
                </tr>
                <tr>
                    <th><?= $model->getAttributeLabel('contacts') ?></th>
                    <td><?= $model->contacts ?></td>
                </tr>
                <?php if ($me): ?>
                    <tr>
                        <th><?= Yii::t('app', 'Transportation') ?></th>
                        <td>
                            <?php if ($me->transportation): ?>
                                <strong><?= \common\components\helpers\AppConst::$TRANSPORTATION[$me->transportation] ?></strong>
                                <br>
                                <?php if ($me->transportation == \common\components\helpers\AppConst::NEED_TRANSPORT): ?>
                                    <em>This line will change when we have arrange transport for you.</em>
                                    <br>
                                <?php endif ?>
                                But, you still can change your transportation preference with button below:
                                <br>
                            <?php endif; ?>
                            <?= Html::a(Yii::t('app', 'Self service'), ['/event-participant/transportation', 'id' => $model->id, 'mode' => 'SS'], ['class' => 'btn btn-primary']) ?>
                            &nbsp;
                            <?= Html::a(Yii::t('app', 'I have vehicle(s)'), ['/event-participant/transportation', 'id' => $model->id, 'mode' => 'HV'], ['class' => 'btn btn-success']) ?>
                            &nbsp;
                            <?= Html::a(Yii::t('app', 'I Need transport'), ['/event-participant/transportation', 'id' => $model->id, 'mode' => 'NT'], ['class' => 'btn btn-warning']) ?>
                        </td>
                    </tr>
                <?php endif ?>
                <?php if (!empty($me)): ?>
                    <?php if ($me->paid == "N"): ?>
                        <tr>
                            <th><?= Yii::t('app', 'Information') ?></th>
                            <td>
                                <?= Html::a(Yii::t('app', 'What you need to know'), ['transportation', 'id' => $model->id, 'mode' => 'SS'], ['class' => 'url url-info']) ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endif; ?>
            </table>
        </div>
        <div class="box-footer">
            <?= $model->description_full ?>
        </div>
    </div>
</article>