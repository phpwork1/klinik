<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model backend\models\Event */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Events'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
$this->params['buttons'][] = Html::a('<i class="glyphicon glyphicon-download-alt"></i>', ['/event-participant/create', 'event_id' => $model->id], ['class' => 'btn btn-success']);
$this->params['buttons'][] = Html::a('<i class="glyphicon glyphicon-envelope"></i>', ['/mail/create', 'event_id' => $model->id], ['class' => 'btn btn-info']);
$this->params['buttons'][] = Html::a('<i class="glyphicon glyphicon-pencil"></i>', ['update', 'id' => $model->id], ['class' => 'btn btn-warning']);
$this->params['buttons'][] = Html::a('<i class="glyphicon glyphicon-remove"></i> ', ['delete', 'id' => $model->id], [
    'class' => 'btn btn-danger',
    'data' => [
        'confirm' => Yii::t('app', 'Are you sure you want to delete this item?'),
        'method' => 'post',
    ],
]);
?>
<div class="box box-info">
    <div class="box-header with-border">
        <h3 class="box-title"><?= Html::encode($this->title) ?></h3>
    </div>

    <div class="box-body event-type-form table-responsive">
        <table class="table table-hover table-striped detail-view">
            <tr>
                <th><?= $model->getAttributeLabel('type_id') ?></th>
                <td><?= $model->type->name ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('name') ?></th>
                <td><?= $model->name ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('description_short') ?></th>
                <td><?= $model->description_short ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('description_full') ?></th>
                <td><?= $model->description_full ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('venue') ?></th>
                <td><?= $model->venue ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('address') ?></th>
                <td><?= $model->address ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('district_id') ?></th>
                <td><?= $model->district_id ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('regency_id') ?></th>
                <td><?= $model->regency->name ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('province_id') ?></th>
                <td><?= $model->province->name ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('country_id') ?></th>
                <td><?= $model->country->name ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('location') ?></th>
                <td><?= $model->location ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('teachers') ?></th>
                <td><?= $model->teachers ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('assistants') ?></th>
                <td><?= $model->assistants ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('fee') ?></th>
                <td><?= $model->fee ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('contacts') ?></th>
                <td><?= $model->contacts ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('start') ?></th>
                <td><?= $model->start ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('end') ?></th>
                <td><?= $model->end ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('application_deadline') ?></th>
                <td><?= $model->application_deadline ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('payment_deadline') ?></th>
                <td><?= $model->payment_deadline ?></td>
            </tr>
            <tr>
                <th><?= $model->getAttributeLabel('created_at') ?></th>
                <td><?= $model->created_at ?> / <?= $model->createdBy->username ?></td>
            </tr>
            <?php if (!empty($model->updated_by)): ?>
                <tr>
                    <th><?= $model->getAttributeLabel('updated_at') ?></th>
                    <td><?= $model->created_at ?> / <?= $model->createdBy->username ?></td>
                </tr>
            <?php endif ?>
            <?php if (!empty($model->deleted_by)): ?>
                <tr>
                    <th><?= $model->getAttributeLabel('deleted_at') ?></th>
                    <td><?= $model->created_at ?> / <?= $model->deletedBy->username ?></td>
                </tr>
            <?php endif ?>
        </table>
    </div>
</div>

<div class="panel panel-success">
    <div class="panel-heading">
        <?= Yii::t('app', 'Participants'); ?>
    </div>
    <div class="panel-body no-padding table-responsive">
        <?= $this->renderAjax('/event-participant/index', ['dataProvider' => $participants, 'searchModel' => false]) ?>
    </div>
</div>