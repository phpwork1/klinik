<?php
use yii\helpers\Html;

/* @var $this yii\web\View */

$this->title = 'Beranda';
?>
<div class="site-index row">
    <div class="col-md-4">
        <legend><?= Yii::t('app', 'Notifications') ?></legend>
        <ul>
            <li>Penjualan yang belum lunas sampai saat ini
        </ul>
        <legend><?= Yii::t('app', 'Mail') ?></legend>
        <ul>
            <li>Mail per event
        </ul>
    </div>
</div>
